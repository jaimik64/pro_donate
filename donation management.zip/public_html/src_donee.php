<?php
    $timezone = "Asia/Calcutta";
    require 'db.php';
    $s=$_POST['amt'];
    $i=$_COOKIE['ct'];
    
    if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
    $current_d       =  date('Y-m-d');
    // $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="select * from application where req_m='$s' and cat_no=(select cat_no from catagory where cat_name='$i')  and last_date>='".$current_d."'";
    $e=mysqli_query($con,$q);
    if(mysqli_num_rows($e))
    {
        
?>
<html>
    <head>
        <link rel="stylesheet" href="s2.css" type="text/css">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <style>
            
        </style>
    </head>
    <body><center>
        <table border="2">
            <tr>
            <th>Application NO</th>
            <th>Donee Name/ ID</th>
            <th>Required Money</th>
            <th>Last Date</th>
            <th>Remarks</th>
            </tr>
            <?php
                
                
                while($r=mysqli_fetch_array($e))
                {
            ?>
            <tr>
                <td><?php echo $r['reno']; ?></td>
                <td><?php echo $r['dnid']; ?></td>
                <td><?php echo $r['req_m']; ?></td>
                <td><?php echo $r['last_date']; ?></td>
                <td><?php echo $r['remarks']; ?></td>
            </tr>
            <?php
                }}
                else{
            ?>
        </table>
        <?php
                echo "Sorry, No Data Available";
                }
            ?>
    </center>
    </body>
</html>