<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
<body>
<form method="post" action="">
CATNAME:<input type="text" name="cn" style="border-radius:5px;"><br><BR>
city:<input type="text" name="ci" style="border-radius:5px;"><br><BR>
state:<input type="text" name="st" style="border-radius:5px;"><br><BR>
<input type="submit" name="sub" value="CREATE" style="background-color:lightblue;font-family:verenda;"><br>
</form>
<?php
    require 'db.php';
	if(isset($_POST['sub']))
	{
	$cn=$_POST['cn'];
	$ci=$_POST['ci'];
	$st=$_POST['st'];

	
	$q="insert into catagory values('','$cn','$ci','$st')";
	if(mysql_query($q,$con))
	echo "successfull";
	else
	echo "error";
	}
?>
	

