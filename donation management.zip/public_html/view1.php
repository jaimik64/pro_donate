<html>
    <head></head>
    <body>
<div class="menu" style="background-color:#ffffff;width:100%;opacity:0.7;">
<a href="donee.php">HOME</a>
<a href="doneep.php">PROFILE</a>
<a href="viewreq.php">VIEW REQUEST</a>
<a href="support.php">SUPPORT</a>
<a href="logout.php" class="lg1" style="float:right;">LOG OUT</a>
</div>
        <?php
        session_start();
        require 'db.php';
        // $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
        $p=$_GET['user'];
       // $r=$_GET['req'];
        $q="select * from donee where username='$p'";
        $e=mysqli_query($con,$q);
        $c=mysqli_fetch_array($e);
        echo '<img src="data:image/jpeg;base64,'.base64_encode($c['proof']).'"/>';
        if($_SESSION['usertype']=="donee")
        {
        ?>
            <form action="updateproof.php" method="post" enctype="multipart/form-data">
                <input type="file" name="proof"></input>
                <input type="submit" name="sub" value="update"></input>
            </form>
        <?php }?>
        </body>
    </html>