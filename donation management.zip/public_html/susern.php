<?php
		
		session_start();
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\SMTP;
		use PHPMailer\PHPMailer\Exception;

		// Load Composer's autoloader
		require 'vendor/autoload.php';
	    require 'db.php';
	function smail($o,$m)
	{
	
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
	

		// Instantiation and passing `true` enables exceptions
		try{$mail = new PHPMailer(true);

	
			//Server setting
			// Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'prodonate007@gmail.com';                     // SMTP username
			$mail->Password   = 'Jaimik#64';                             // SMTP password
			$mail->SMTPSecure = tls;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('from@example.com', 'ProDonate');    // Add a recipient
			$mail->addAddress($m);               // Name is optional
			

			// Attachments
			//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			// Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'USERNAME';
			$mail->Body    = 'This is your username is <br>'.$o;
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
		}
		
catch(phpmailerException $e){
	    echo $e->errorMessage();
	}
	catch(Exception $e){
	    echo $e->getMessage();
	}
    
			
	}
			

	$type=$_POST['idp'];
	$_SESSION['idp']=$type;
	$em=$_POST['em'];
	$_SESSION['email']=$em;
    //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
	if($type=="donor")
	{
    	$q="select * from donar where email='$em'";
		$r=mysqli_query($con,$q);
		if($c=mysqli_fetch_array($r))
		{
			$otp=$c['username'];
			smail($otp,$em);
				$_SESSION['suc']=false;
			header("location:forgotus.php");
		}
		else
		{
			$_SESSION['noemi']=false;
			header("location:forgotus.php");
		}

	}
	else if($type=="donee")
	{
		$q="select * from donee where email='$em'";
		$r=mysqli_query($con,$q);
		if($c=mysqli_fetch_array($r))
		{
			$otp=$c['username'];
			smail($otp,$em);
				$_SESSION['suc']=false;
			header("location:forgotus.php");
		}
		else
		{
			$_SESSION['noemi']=false;
			header("location:forgotus.php");
		}
	}
?>