<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <style>
            body{
                background-image:url("DMS.jpg");
                
            }
            .container
            {
                opacity:0.5;
                border-radius:20px;
                background-color:black;
                
            }
        </style>
        <title>Bank Page</title></head>
    <body>
        <div class="container">
            
        </div>
    </body>
</html>