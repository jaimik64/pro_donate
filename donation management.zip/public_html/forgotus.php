<?php session_start(); ?>
<html>
    <head>
        <link rel="stylesheet" href="s2.css">
        <link rel="icon" href="heart.png">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
    <body>
        <div class="box" style="border-radius:40px;">
            <form method="POST" action="susern.php">
                <span class="text-center">Forgot Username</span>
        	        <select name="idp">
	                    <option>Select User Type</option>
				        <option>donor</option>
				        <option>donee</option>
	                </select>
	                <div class="input-container">
	                    <input type="email" name="em" required>
	                    <label style="margin-top:10px;">Email</label>
	                </div>
                <button class="btn" style=" margin-right:10%;"type="submit" name="signup">Send username</button>
	        </form>
    <?php   
        if(isset($_SESSION['noemi']))
        {
            echo "NO SUCH EMAIL EXIST";
            unset($_SESSION['noemi']);
        }
         if(isset($_SESSION['suc']))
        {
            echo "Username Sent on Your Registered E-mail.";
            header("location:demo.php");
            unset($_SESSION['suc']);
        }
    ?>
        </div>
    </body>
</html>