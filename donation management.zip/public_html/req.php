<?php
    session_start();
    require 'db.php';
      if(time()-$_SESSION['timeout']>18000)
    {
        $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
    $id=$_SESSION['id'];
    	//$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    	$q="select * from donee where username='$id'";
    	$r=mysqli_query($con,$q);
    	$c=mysqli_fetch_array($r);
    	
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="req.css">
        <link rel="icon" href="heart.png">
        <title>Request</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
<div class="box">
<form method="post" action="req_data.php" enctype="multipart/form-data">
        <?php if(empty($c['proof'])&&empty($c['passbook'])){?>
        DOCUMENT SIZE SHOULD BE LESS THAN 100KB.<br>
        	<?php }?>
        <div class="input-container">
		REQUIRED MONEY:<input type="number" name="money" max="8000" style="border-radius:5px;" required><br>
		</div>
			<?php if(empty($c['bname'])&&empty($c['acc_no'])&&empty($c['ifsc'])){?>
		<div class="input-container">
		BANK_NAME:<input type="text" name="bk" style="border-radius:5px;" required><br>
		</div>
		<div class="input-container">
		ACC_NO:<input type="TEXT" name="acc" style="border-radius:5px;" required><br>
		</div>
		<div class="input-container">
		IFSC_CODE:<input type="text" name="ifsc" style="border-radius:5px;" required><br>
		</div>
			<?php }?>
		<div class="input-container">
		LAST_DATE:<input type="date" name="LD" style="border-radius:5px;" rquired><br>
		</div>
		<div class="input-container">
		REMARKS:<input type="TEXT" name="rm" style="border-radius:5px;" required><br>
		</div>
		<?php if(empty($c['proof'])&&empty($c['passbook'])){?>
		<div class="input-container">
		ID_PROOF:<input type="file" name="idphoto" style="border-radius:5px;" required><br>
		</div>
		<div class="input-container">
		PASSBOOK:<input type="file" name="passbook" style="border-radius:5px;" required><br>
		</div>
		<?php }?>
		<div class="input-container">
		CONFIRM CATAGORY:<select name="cc" required>
		    <?php 
		        $q="select * from catagory";
		        $r=mysqli_query($con,$q);
		        while($c=mysqli_fetch_array($r))
		        {?>
				<option><?php echo $c['cat_name'];?></option>
			    <?php } ?> 
				</select></div><br>       
		<button class="btn" style="margin-left:25%;" name="sub">Request</button><br>
</div>
</form>
<?php
    if(isset($_SESSION['submitted']))
    {
        echo "request submitted";
        header("location:donee.php");
        UNSET($_SESSION['submitted']);
    }
      if(isset($_SESSION['not']))
    {
        echo "you cannot request more than 8000";
        UNSET($_SESSION['not']);
    }

   
?>
        
</html>
