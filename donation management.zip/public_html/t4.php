<html>
<head>
<link rel="stylesheet" type="text/css" href="t4.css"> 
</head>
<body>
 <div class="main">
    <div class="side" id="side"><br/>
		<h1>Hello, Friend!</h1>
			<p>Enter your details and start journey with us</p>
      <center><button onclick="sign()">SignUp</button>
	</center>
	</div>
	
				
	<div  style="display:none;"class="signup"  id="sign">
		<center><h1>SignUp Details</h1></center>
		
		<form method="post" action="signup_data.php">
				<label class="type"><input type="radio" name="gen" value="donar">DONOR </label>
				<label class="type"><input type="radio" name="gen" value="donee">DONEE</label>
				<br/>
					
				<input class="input" type="text" name="uid" style="border-radius:5px;" placeholder="UserName" required >
				<input type="text" class="input" name="name" placeholder="Name" style="border-radius:5px;">
				<input class="input"type="password" name="pas" style="border-radius:5px;" placeholder="Enter 8 Characters or more PASSWORD">
				<input type="password" class="input" name="rpas" style="border-radius:5px;" placeholder="Re-Enter  Passwod">
				
					<label class="type"><input type="radio" name="genn" value="male" style="border-radius:5px;">MALE</label>
					<label class="type"><input type="radio" name="genn" value="female" style="border-radius:5px;">FEMALE</label>
				<br/>
				<input type="text"  class="input"name="num" style="border-radius:5px;" placeholder="CONTACT NO">
				<input type="EMAIL" class="input" name="emi" style="border-radius:5px;" placeholder="Email Id" required>
				<input type="hidden" class="input" name="nat" value="indian" style="border-radius:5px;" >
				<label class="type1">ID-PROOF</label>
					<select name="idp" placeholder="ID-PROOF">
						<option>aadhar</option>
						<option>pancard</option>
						</select>
						<br/>
				<input class="input" type="TEXT" name="idpn" placeholder="Id Proof No"style="border-radius:5px;"required>
				<p>DOB  <input  type="date"  max="2002-12-31"name="dob" style="border-radius:5px;" required></p>
				<textarea name="add"  rows="5" cols="20" style="border-radius:5px;" placeholder="ADDRESS" required></textarea>
				<input class="input" type="text" name="city" style="border-radius:5px;" placeholder="City" required>
				</table>
				<center><button  class="btype" name="sub"><span>Sign Up </span></button></center><br>
				<?php	
        			if(isset($_SESSION['empform']))
        			{	
        				alert("PLEASE FILL THE FORM");
        				unset($_SESSION['empform']);
        			}
        			else if(isset($_SESSION['st1']))
        			{	
        				alert("TRY ANOTHER USERNAME ");
        				unset($_SESSION['st1']);
        			}
        			else if(isset($_SESSION['c']))
        			{	
        				echo "<p align=left>"."CONTACT NUMBER ALREADY REGISTERED "." </p>";
        				unset($_SESSION['c']);
        			}
        			else if(isset($_SESSION['err']))
        			{	
        				echo "<p align=left>"."PLEASE ENTER CORRECT PASSWORD "." </p>";
        				unset($_SESSION['err']);
        			}	
        			else if(isset($_SESSION['ps']))
        			{	
        				echo "<p align=left>"."PLEASE ENTER PASSWORD"."  </p>";
        				unset($_SESSION['ps']);
        			}	
        			else if(isset($_SESSION['cont']))
        			{	
        				echo "<p align=left>"."PLEASE ENTER CORRECT PHONE NUMBER "." </p>";
        				unset($_SESSION['cont']);
        			}
        			else if(isset($_SESSION['sel']))
        			{	
        				echo "<p align=left>"."PLEASE SELECT TYPE DONOR OR DONEE"."</p> ";
        				unset($_SESSION['sel']);
        			}
        			else if(isset($_SESSION['emi']))
        			{
        				echo "THIS EMAIL IS ALREADY REGISTERED ";
        				unset($_SESSION['emi']);
        			}
        			else if(isset($_SESSION['eigc']))
        			{	
        		
        				echo "PASSWORD MUST ATLEAST 8 CHARACTERS LONG";
        				unset($_SESSION['eigc']);
        			}
        			else if(isset($_SESSION['idp1']))
        			{
        			    echo "AADHAR NUMBER SHOULD OF 12 DIGITS";
        			    unset($_SESSION['idp1']);
        			}
                    else if(isset($_SESSION['idp2']))
        			{
        			    echo "PAN CARD NUMBER SHOULD 10 DIGITS";
        			    unset($_SESSION['idp2']);
        			}
        			echo "print";
        		?>

				</form>
		</div>
	
	<div style="display:none;" class="login1" id="log"><center>This Is LogIn
	<h2>Welcome Back!</h2><p>To Keep Connected With Us please login with Your Personal Info</p></center>
	<button onclick="hide()">LogIn</button>
	<script>
	function hide()
	{
			document.getElementById("side").style.display='block'; //hide side
				document.getElementById("sign").style.display='none'; //show signup form
				document.getElementById("log").style.display='none'; //show log
				document.getElementById("login").style.display='block'; //hide login
	}
	</script> 
	</div>
	
	
	<div class="login" id="login"><br/>
      <center><h1 class="head">LogIn Details</h1></center>
      <form method="post" action="check.php" id="form">
       <center>
        <label><input type="radio" name="sel" value="donor">Donor</label>&nbsp;
        <label><input type="radio" name="sel" value="donee">Donee</label><br/><br/>
         <input type="text" name="un" placeholder="UserName" class="inp"><br/>
         <br/>
         <input type="password" name="ps" placeholder="Password" class="inp"><br/><br/>
		 <a href="forgotpass.php">Forgot Your Password</a><br/><br/>
		 
         <input type="submit" name="lg" value="Log In"/> 
         </form>
         <div style="color:white;" ><?php	
	
			if(isset($_SESSION['st']))
			{
				echo "<center>";
				echo " WRONG USERNAME OR PASSWORD";
				echo "</center>";
				unset($_SESSION['st']);
			}	
			else if(isset($_SESSION['sel']))
			{	
				echo "<center>";
				echo "PLEASE SETECT TYPE DONAR,DONEE OR ADMIN";
				echo "</center>";
				unset($_SESSION['sel']);
			}
			//clearing signup from sessions.
				/*unset($_SESSION['u']);
				unset($_SESSION['p']);
				unset($_SESSION['rp']);
    			unset($_SESSION['d']);
		    	unset($_SESSION['ci']);
    			unset($_SESSION['e']);
				unset($_SESSION['nn']);
				unset($_SESSION['in']);
				unset($_SESSION['i']);
                unset($_SESSION['n']);
unset($_SESSION['sta']);*/
?></div>
    </div>
 </div>
 <script> 
	function sign(){
				document.getElementById("side").style.display='none'; //hide side
				document.getElementById("sign").style.display='block'; //show signup form
				document.getElementById("log").style.display='block'; //show log
				document.getElementById("login").style.display='none'; //hide login
			}  
	
		</script>
</body>  
</html>