<?php
    ob_start();
	session_start();
	$_SESSION['u']=$_POST['uid'];
	$_SESSION['n']=$_POST['name'];
	$_SESSION['p']=$_POST['pas'];
	$_SESSION['rp']=$_POST['rpas'];
	$_SESSION['nn']=$_POST['num'];
    $_SESSION['e']=$_POST['emi'];
    $_SESSION['ai']=$_POST['add'];
	$_SESSION['ci']=$_POST['city'];
	$un=$_POST['uid'];
	$name=$_POST['name'];
	$ps=$_POST['pas'];
	$rps=$_POST['rpas'];
	$cont=$_POST['num'];
	$em=$_POST['emi'];
	$add=$_POST['add'];
	$cit=$_POST['city'];
	$us="";
	$us1="";
	$us2="";
	$us3="";
	$us4="";
	
	
	$en=password_hash($ps,PASSWORD_DEFAULT);
    $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q1="select * from donar where username='$un'";
    $emailcheck="select * from donee where email='$em'";
     $emailcheck1="select * from donar where email='$em'";
     $emicheck=mysqli_query($con,$emailcheck);
     $emicheck1=mysqli_query($con,$emailcheck1);
     if(mysqli_num_rows($emicheck)!=0 || mysqli_num_rows($emicheck1)!=0)
     {
         $_SESSION['emi']=false;
         header("location:adminsignup.php");
         exit();
     }
    $ce=mysqli_query($con,$q1);
    

	while($re=mysqli_fetch_array($ce))
		{
			$us2=$re['username'];
		}
        $q2="select * from donee where username='$un'";
        $ce1=mysqli_query($con,$q2);
    	while($re1=mysqli_fetch_array($ce1))
		{
			$us1=$re1['username'];
		}
        $q3="select contact from admin where contact='$cont'";
        $ce2=mysqli_query($con,$q3);
    	while($re2=mysqli_fetch_array($ce2))
		{
			$us3=$re2['contact'];
		}
		$q4="select email from admin where email='$em'";
        $ce4=mysqli_query($con,$q4);
    	while($re4=mysqli_fetch_array($ce4))
		{
			$us4=$re4['email'];
		}
		$q="select * from admin where username='$un'";
		$c=mysqli_query($con,$q);
		while($r=mysqli_fetch_array($c))
		{
			$us=$r['username'];
		
		}
		if($un==$us)
		{
			$_SESSION['st']=false;
			header("location:adminsignup.php");
			exit();
		}
		else if($un==$us1)
		{
			$_SESSION['st']=false;
			header("location:adminsignup.php");
			exit();
			
		}
		else if($un==$us2)
		{
			$_SESSION['st']=false;
			header("location:adminsignup.php");
			exit();
			
		}
	    else if($em==$us4)
		{
			$_SESSION['emi']=false;
			header("location:adminsignup.php");
			exit();
		}
		else if(strlen($ps)<=7)
		{
			$_SESSION['eigc']=false;
			header("location:adminsignup.php");
			exit();
			
		}
		else if($cont==$us3)
		{
		    $_SESSION['cont']=false;
		    header("location:adminsignup.php");
		    exit();
		}
		else if($ps==$rps)
		{
			$q1="insert into admin values('$un','$name','$en','$cont','$em','$add','$cit')";
			$j=mysqli_query($con,$q1);
			if($j)
			{
			header("location:demo.php");
			exit();
			}
		}
		else
		{
			$_SESSION['err']=false;
			header("location:adminsignup.php");
			exit();
			
		}
?>