<?php
 session_start();
 require 'db.php';
 $p=$_SESSION['id'];
  //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
      if(isset($_POST['sub']) && isset($_FILES['proof']))
        {
            	$idphoto=addslashes(file_get_contents($_FILES['proof']['tmp_name']));
            	$q1="UPDATE donee SET passbook='$idphoto' where username='$p'";
            	if(mysqli_query($con,$q1))
            	{
            	    header("location:doneep.php");
            	    exit();
            	  
            	}
            	else
            	{
            	    echo "error";
            	}
        }
?>