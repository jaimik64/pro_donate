<?php 
session_start();
require 'db.php';
$en=$_SESSION['id'];
   if(time()-$_SESSION['timeout']>18000)
    {
         $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
	if($_SESSION['id']==true)
	{
	
	}
	else
	{
	    header("location:demo.php");
	    exit();
	}
   // $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
	$q="select*from donar where username='$en'";
   $c=mysqli_query($con,$q);
     $r=mysqli_fetch_array($c);
?>

<html>
    <head>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <style>
            
        .box{
        	position:absolute;
        	left:50%;
        	top:50%;
        	opacity:0.8;
        	transform: translate(-50%,-50%);
            background-color: rgba(0, 0, 0, 0.89);
        	border-radius:20px;
        	padding:70px 100px;
        	margin-top:50px;
        }
@import 'https://fonts.googleapis.com/css?family=Montserrat:300,400,700';

body {
  padding: 0 2em;
  font-family: Montserrat, sans-serif;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  color: white;
  background: #eee;
  font-size:24px;
}

.rwd-table {
  color: #fff;
  border-radius: .4em;
  overflow: hidden;
}
  tr {
    border-color: lighten(#34495E, 10%);
  }
  th, td {
    margin: .5em 1em;
    @media (min-width: $breakpoint-alpha) { 
      padding: 1em !important; 
    }
  }
  th, td:before {
    color: #dd5;
  }
  h1 {
  font-weight: normal;
  letter-spacing: -1px;
  color: white;
}
.btn1
{
	color:#fff;
	background-color:#e74c3c;
	outline: none;
    border: 0;
	padding:5px 10px;
	text-transform:uppercase;
	margin-top:20px;
	margin-left:200px;
	border-radius:2px;
	cursor:pointer;
	position:relative;
}
a{
    color:white;
}
.select1{
border:0;
  border-bottom:1px solid #555;  
  background:transparent;
  width:30%;
  padding:8px 0 5px 0;
  font-size:16px;
  color:#fff;
}
.menu{
    height:5%;
    background-color:white;
    opacity:0.7;
    font-size:16px;
    color:blue;
    margin-bottom:50px;
    
}

        </style>
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="s2.css">
        <link rel="icon" href="heart.png">
    <title>Profile</title>
    </head>
<body>
    <div class="menu">
        <a style="color:blue;padding-left:10px;text-decoration:none;" href="donar.php">Home</a>
        <a style="color:blue;padding-left:10px;text-decoration:none;"href="donarp.php">Profile</a>
        <a style="color:blue;padding-left:10px;text-decoration:none;" HREF="donation_log.php"> Donation Log</A>
        <a style="color:blue;padding-left:10px;text-decoration:none;" HREF="support.php">Suggestion/Query?</A>
    </div>
    <div class="box">
    <span class="text-center">PROFILE</span>
	<table class="rwd-table">
		<tr>
			<th>name</th>
			<td><?php echo $r['name'];?></td>
		</tr>
		<tr>
			<th>id_proof_no</th>
			<td><?php echo $r['id_proof_no'];?></td>
		</tr>
		<tr>
			<th>contact</th>
			<td><?php echo $r['contact'];?></td>
		</tr>
		<tr>
			<th>email</th>
			<td><?php echo $r['email'];?></td>
		</tr>
		<tr>
			<th>State</th>
			<td><?php echo $r['state'];?></td>
		</tr>
		<tr>
			<th>City</th>
			<td><?php echo $r['city'];?></td>
		</tr>
		<tr>
			<th>DOB</th>
			<td><?php echo $r['DOB'];?></td>
		</tr>
		<tr>
			<th>Gender</th>
			<td><?php echo $r['gender'];?></td>
		</tr>
	</table>
	
	<form method="post" action="">
	Donation-Status:<select class="select1" name="dstatus">
	    <option>hidden</option>
	    <option>visible</option>
	</select>
	<button class="btn1" type="submit" name="sub" value="Change Status">Change Status</button>
	</form>

    <?php
	   if(isset($_POST['sub']))
	    { 
	        $s=$_POST['dstatus'];
		    $q1="UPDATE donar SET dshowstatus='$s' WHERE username='$en'";
	        $r=mysqli_query($con,$q1);
	    //echo "Status No";
	     if($r)
	        {
	             echo "Status Changed..";
	        }
	    }
	    $h=200;
	    $w=100;
    ?>
<br/>
	<a href="donarupd.php?id=<?php echo $r['username']?>">UPDATE PROFILE</a><br>
	<a href="cpassdonar.php?id=<?php echo $r['username']?>">Update PASSWORD</a><br>
	<a href="cuserndonar.php?id=<?php echo $r['username']?>&em=<?php echo $r['email']?>">CHANGE USERNAME</a><br>
	<a href="cemaildonar.php?id=<?php echo $r['username']?>&em=<?php echo $r['email']?>">Update EMAIL</a><br>
	</div>
	</body>
	</html>