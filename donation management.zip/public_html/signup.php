<?php session_start();
 ?>
<html>
    <head>
         <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
         <link rel="icon" href="heart.png">
		 <link rel="stylesheet" href="signup.css">
		 <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <style>
   /* .btype {
  display: inline-block;
  border-radius: 4px;
  background-color: #87CEFA;
  border: none;
  color: black;
  text-align: center;
  font-size: 12px;
  padding: 8px;
  wid: 110px;
  height:25px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.btype span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.btype span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.btype:hover span {
  padding-right: 25px;
}

.btype:hover span:after {
  opacity: 1;
  right: 0;
}*/
.c:checked{
    color:blue;
    background-color:black;
}
</style>
<title>Sign Up</title>
</head>
<body>
<b>
<div class="box">
	<form method="POST" action="signup_data.php" enctype="multipart/form-data">
	<span class="text-center">SIGN UP</span>
	    
	    <div style="margin-bottom:10px;">
	       <label> <input type="radio" class="c" name="gen" value="donar" style="margin-left:10px;" requierd checked>Donor</label>
			<label><input type="radio" class="c" name="gen" value="donee" style="margin-left:20px;" required>Donee</label>
        </div>
			
		<div class="input-container">
			<input type="text" name="uid" value="<?php if(isset($_SESSION['u'])){ echo $_SESSION['u'];}?>" required>
			<label>USERNAME</label>
		</div>
		
		<div class="input-container">
			<input type="text" name="name" value="<?php if(isset($_SESSION['n'])){ echo $_SESSION['n'];}?>" required>
			<label>NAME</label>
		</div>
		<div class="input-container">
			<input type="password" name="pas" maxlength="16" value="<?php if(isset($_SESSION['p'])){ echo $_SESSION['p'];}?>"  required>
			<label>PASSWORD</label>
		</div>
		<div class="input-container">
			<input type="password" name="rpas" maxlength="16" value="<?php if(isset($_SESSION['rp'])){ echo $_SESSION['rp'];}?>" required>
			<label>RE-ENTER PASSWORD</label>
		</div>	
		
		<div style="margin-bottom:10px;">
			<label><input type="radio"  id="m" name="genn" value="male" style="margin-left:10px;" required checked>MALE</label>
			<label><input type="radio"  name="genn" value="female" style="margin-left:20px;" required>FEMALE</label>
		</div>	
		<div class="input-container">
			<input type="text" name="num" maxlength="10" value="<?php if(isset($_SESSION['nn'])){ echo $_SESSION['nn'];}?>" required>
			<label>CONTACT</label>
		</div>
		<div class="input-container">
			<input type="EMAIL" name="emi"  value="<?php if(isset($_SESSION['e'])){ echo $_SESSION['e'];}?>" required>
			<label>EMAIL ID </label>
		</div>	
			<input type="hidden" name="nat" value="indian">
		
	
			<select name="idp" value="<?php if(isset($_SESSION['i'])){ echo $_SESSION['i'];}?>" placeholder="SELECT ID">
			    <option>Select Id Proof Type</option>
				<option>Aadhar</option>
				<option>Pancard</option>
			</select>
		<div class="input-container">
			<input type="TEXT" name="idpn" maxlength="12" minlength="10" value="<?php if(isset($_SESSION['in'])){ echo $_SESSION['in'];}?>" required>
			<label>ID-PROOF-NO</label>
		</div>
		<div class="input-container">
			<p>DOB</p>
			<input type="date" max="2002-12-31" name="dob" value="<?php if(isset($_SESSION['d'])){ echo $_SESSION['d'];}?>" required>
		</div>
		<div class="input-container">
			<textarea name="add" rows="5" cols="20" value="<?php if(isset($_SESSION['ai'])){ echo $_SESSION['ai'];}?>" placeholder="Address"required></textarea>
		</div>
		<div class="input-container">
			<input type="text" name="city" value="<?php if(isset($_SESSION['ci'])){ echo $_SESSION['ci'];}?>" required>
			<label>CITY</label>
		</div>
		<div class="input-container">
			<select name="state" required>
					<option value="">------------Select State------------</option>
					<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
					<option value="Andhra Pradesh">Andhra Pradesh</option>
					<option value="Arunachal Pradesh">Arunachal Pradesh</option>
					<option value="Assam">Assam</option>
					<option value="Bihar">Bihar</option>
					<option value="Chandigarh">Chandigarh</option>
					<option value="Chhattisgarh">Chhattisgarh</option>
					<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
					<option value="Daman and Diu">Daman and Diu</option>
					<option value="Delhi">Delhi</option>
					<option value="Goa">Goa</option>
					<option value="Gujarat">Gujarat</option>
					<option value="Haryana">Haryana</option>
					<option value="Himachal Pradesh">Himachal Pradesh</option>
					<option value="Jammu and Kashmir">Jammu and Kashmir</option>
					<option value="Jharkhand">Jharkhand</option>
					<option value="Karnataka">Karnataka</option>
					<option value="Kerala">Kerala</option>
					<option value="Lakshadweep">Lakshadweep</option>
					<option value="Madhya Pradesh">Madhya Pradesh</option>
					<option value="Maharashtra">Maharashtra</option>
					<option value="Manipur">Manipur</option>
					<option value="Meghalaya">Meghalaya</option>
					<option value="Mizoram">Mizoram</option>
					<option value="Nagaland">Nagaland</option>
					<option value="Orissa">Orissa</option>
					<option value="Pondicherry">Pondicherry</option>
					<option value="Punjab">Punjab</option>
					<option value="Rajasthan">Rajasthan</option>
					<option value="Sikkim">Sikkim</option>
					<option value="Tamil Nadu">Tamil Nadu</option>
					<option value="Tripura">Tripura</option>
					<option value="Uttaranchal">Uttaranchal</option>
					<option value="Uttar Pradesh">Uttar Pradesh</option>
					<option value="West Bengal">West Bengal</option>
			</select>
		</div>
		<button  class="btn" name="sub"><span>Sign Up </span></button><br>

</form>
	<div style="text-align:left; color:white;  height:1%; wid:60%;">
		<?php	
			if(isset($_SESSION['empform']))
			{	
				echo "<p align=left>"."PLEASE FILL E FORM". "</p> ";
				unset($_SESSION['empform']);
			}
			else if(isset($_SESSION['st1']))
			{	
				echo "<p align=left>"."TRY ANOER USERNAME "." </p>";
				unset($_SESSION['st1']);
			}
			else if(isset($_SESSION['c']))
			{	
				echo "<p align=left>"."CONTACT NUMBER ALREADY REGISTERED "." </p>";
				unset($_SESSION['c']);
			}
			else if(isset($_SESSION['err']))
			{	
				echo "<p align=left>"."PLEASE ENTER CORRECT PASSWORD "." </p>";
				unset($_SESSION['err']);
			}	
			else if(isset($_SESSION['ps']))
			{	
				echo "<p align=left>"."PLEASE ENTER PASSWORD"."  </p>";
				unset($_SESSION['ps']);
			}	
			else if(isset($_SESSION['cont']))
			{	
				echo "<p align=left>"."PLEASE ENTER CORRECT PHONE NUMBER "." </p>";
				unset($_SESSION['cont']);
			}
			else if(isset($_SESSION['sel']))
			{	
				echo "<p align=left>"."PLEASE SELECT TYPE DONOR OR DONEE"."</p> ";
				unset($_SESSION['sel']);
			}
			else if(isset($_SESSION['emi']))
			{
				echo "THIS EMAIL IS ALREADY REGISTERED ";
				unset($_SESSION['emi']);
			}
			else if(isset($_SESSION['eigc']))
			{	
		
				echo "PASSWORD MUST ATLEAST 8 CHARACTERS LONG";
				unset($_SESSION['eigc']);
			}
			else if(isset($_SESSION['idp1']))
			{
			    echo "AADHAR NUMBER SHOULD OF 12 DIGITS";
			    unset($_SESSION['idp1']);
			}
            else if(isset($_SESSION['idp2']))
			{
			    echo "PAN CARD NUMBER SHOULD 10 DIGITS";
			    unset($_SESSION['idp2']);
			}
			else
			{
				echo "";
			}
		?>
		</div>
<div class="demo"><a href="demo.php" style="color:white;">Already Donor Or Donee</a></div>
	</div></center>
	

		

</b>
</body>
</html>