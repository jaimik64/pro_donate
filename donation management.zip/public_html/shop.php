<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
<body>
<form method="post" action="checkout.php">
	SELECT AMOUNT:
	<select name="sel">
	<option>100</option>
	<option>200</option>
	</select>
<form>
<body>
<html>
	
	