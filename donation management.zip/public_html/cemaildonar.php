<?php
    require 'db.php';
?>
<html>
   
        <head>
                 <link rel="stylesheet" type="text/css" href="s2.css">
                 <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        </head>
         <body>
                 <div class="menu" style="background-color:#ffffff;width:100%;opacity:0.7;">
<a href="donar.php">Home</a>
<a href="donarp.php">Profile</a>
<A HREF="donation_log.php"> Donation Log</A>
<A HREF="support.php"> Suggestion/Query?</A>
<a href="logout.php" class="lg" style="float:right">  LOG OUT</a>&nbsp;
<A HREF="donarp.php" > Back  </A>

</div>
             <div class="box">
        <form action="" method="post">
            <div class="input-container">
            ENTER NEW EMAIL:<input type="text" name="us"  minlength="6" required>
            <button type="submit" name="sub" style="margin-top:10px;">change</button>
           </div>
        </form>
        </div>
    </body>
</html>
<?php
session_start();
if(time()-$_SESSION['timeout']>18000)
    {
         $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
$id=$_GET['id'];
$em=$_GET['em'];
if(isset($_POST['sub']))
{
    $us=$_POST['us'];
$q5="select * from donar where email='$us'";
$v=mysqli_query($con,$q5);
$re=mysqli_fetch_array($v);
$q7="select * from admin where email='$us'";
$v2=mysqli_query($con,$q7);
$re2=mysqli_fetch_array($v2);

if($re['email']==$us)
{
    echo "this email already exists";
}




else if($re2['email']==$us)
{
    echo "this email already exists";
}
else
{
$q="UPDATE donar SET email='$us' WHERE username='$id'";
$e=mysqli_query($con,$q);
if($e)
{
    echo "email updated successfully";
  
}
else
{
    echo mysqli_error($con);
}
}
}
?>