<?php
    session_start();
    require 'db.php';
    if(time()-$_SESSION['timeout']>18000)
    {
         $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
    $id=$_SESSION['id'];
    //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="select * from donee where username='$id'";
    $r=mysqli_query($con,$q);
    while($c=mysqli_fetch_array($r))
    {
        
  ?>  
  <html>
     
      <head>
          <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
          <title> Donee Update</title>
         <link rel="stylesheet" type="text/css" href="donar_update.css">
         <style>
             .input-container input{ 
  border:0;
  border-bottom:1px solid #555;  
  background:transparent;
  width:100%;
  padding:8px 0 5px 0;
  font-size:16px;
  color:#fff;
}
         </style>
          
      </head>
      <body>
               <div class="box">
            <span class="text-center">Update Bank Details</span>
      <form action="" method="post">
            
            <div class="input-container">
                <lable style="font-weight:bold;">BankName</lable>
                <input type="text" name="bn" value="<?php echo $c['bname']; ?>">
            </div>
              
              <div class="input-container">
                  <lable style="font-weight:bold;">Account Number<lable>
                   <input type="text" name="acc" value="<?php echo $c['acc_no']; ?>"> 
              </div>  
              <div class="input-container"> 
                  <lable style="font-weight:bold;">IFSC<lable>
                   <input type="text" name="ifsc" value="<?php echo $c['ifsc']; ?>"> 
              </div> 
               <input type="submit" name="sub" value="update">
             </form>
             </div>
            
        </body>
        <?php }
   if(isset($_POST['sub']))
   {
    $bn=$_POST['bn'];
    $ifsc=$_POST['ifsc'];
    $acc=$_POST['acc'];

  
    $q="update donee set bname='$bn', acc_no='$acc', ifsc='$ifsc' where username='$id'";
    $r=mysqli_query($con,$q);
    	
    if($r)
    {
        header("location:doneep.php");
    }
    else
    {
        header("location:updbnk.php");
    }
   }
    ?>