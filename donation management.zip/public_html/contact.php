<html>
<head>
       <link rel="icon" href="heart.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="index.css">
<title>Contact Us </title>
<style>
.p{
  font-size: 36px;
}
tr{
  font-size: 36px;
  }
  @media screen and(max-width:360px)
  {
     .p{
         font-size:20px;
     }
     tr{
         font-size:20px;
     }
  }
</style>
</head>
<body>
<div class="main">
	<div class="title"> <center><h1> Donate <p> For a Better World</p></h1>
	</center>
	</div>
	<div class="menu">
    	<a href="index.php"> Home</a>
	    <a href="gallery.php">Gallery</a>
	    <a href="contact.php">Contact Us </a>
	    <a href="demo.php">&nbsp;  Log In   </a>
	</div>
	<div class="content">
    <center style="padding-top:100px;">
      <table>
        <tr>
        <td>  Mobile No  </td>
        <td style="padding-left:20px;"> +91 69875 65874 / +91 98562 32544</td>
      </tr>
      <tr>
        <td>Email  </td>
          <td style="padding-left:20px;"> jaimikc@gmail.com </td>
        </tr>
        <tr>
          <td>Address</td>
          <td style="padding-left:20px;"> VVN, Anand</td>
        </tr>

          </address>
      </table>
  </center>
	</div>
</div>
</body>
</html>
