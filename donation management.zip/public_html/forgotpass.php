<?php session_start(); 
  ?>
<html>
    <head>
        <link rel="icon" href="heart.png">
 <link href="https://fonts.googleapis.com/css?family=Nunito:600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="s2.css">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <title>Forgot Password</title>
        <style>
            select{
                border:0;
  border-bottom:1px solid #555;  
  background:transparent;
  width:100%;
  padding:8px 0 5px 0;
  font-size:16px;
  color:#fff;
}
    option{
        color:black;
    }
        </style>
    </head>
    <body>
         <div class="box" style="border-radius:40px;">
    <form method="POST" action="submitotp.php">
    <span class="text-center">FORGOT PASSWORD</span>
   <div class="input-container">
    <select name="idp">
	            <option  value="0">Select Type</option>
				<option>donor</option>
				<option>donee</option>
		</select>
	</div>
	<div class="input-container">
	    <input type="email" name="em" required />
	    <label>ENTER-EMAIL</label>
	</div>
	<button class="btn" type="submit" name="signup">Send OTP</button>

	
</form>
  <?php if(isset($_SESSION['noemi']))
    {
        echo "NO SUCH EMAIL EXIST";
        unset($_SESSION['noemi']);
    }
?>
</div>
</body>
</html>