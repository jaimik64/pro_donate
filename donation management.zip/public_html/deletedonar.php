<?php
session_start();

    		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\SMTP;
		use PHPMailer\PHPMailer\Exception;

		// Load Composer's autoloader
		require 'vendor/autoload.php';
	
	function smail($id,$emi)
	{
	
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
	

		// Instantiation and passing `true` enables exceptions
		$mail = new PHPMailer(true);

	
			//Server setting
			// Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   ='fakir4913@gmail.com';                     // SMTP username qmuzwncy@gmail.com
			$mail->Password   = 'ramulo789';                             // SMTP password
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('from@example.com', 'ProDonate');    // Add a recipient
			$mail->addAddress($emi);               // Name is optional
			

			// Attachments
			//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			// Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'ACCOUNT DELETION..';
			$mail->Body    = 'Dear user '.$id.' your account is permenantly deleted due to some reason..';
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
		  
			
	
	}
$id=$_GET['user'];
 $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
 

 $q1="select email from donar where username='$id'";
 $r=mysqli_query($con,$q1);
 $c=mysqli_fetch_array($r);
 $emi=$c['email'];
 $q="delete from donar where username='$id'";
 if(mysqli_query($con,$q))
 {
     smail($id,$emi);
     header("location:donardetail.php");
     exit();
 }
 else
    
    echo "Server Error";
    echo mysqli_error($con);
 
?>