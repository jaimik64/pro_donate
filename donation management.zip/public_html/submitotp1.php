<?php
    session_start();
    if($_SESSION['otp']==true)
    {
        echo "";
    }
    else
    {
        header("location:demo.php");
    }
?>
<html>
<body>
    <head>
        <link rel="icon" href="heart.png">
        <title>Verify OTP</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="s2.css">
    </head>
    <div class="box" style="border-radius:40px;">
        <form method="POST" action="">
            <span class="text-center">Verify OTP</span>
        <div class="input-container">
            <input type="text" name="otp" required>
            <label>OTP</label>
        </div>
        <button class="btn" type="submit"name="sub"> Verify </button>
        	<a href="resendotp.php" style="color:white;margin-top:20px;margin-right:20px;">Resend otp?</a>
    </form>
           <div style="display:block; margin:10px 30px;"> <?php
        	if(isset($_POST['sub']))
        	{
        	    if($_SESSION['otp']==$_POST['otp'] && (time()-$_SESSION['time'])<600)
        	    {
        	        	header("location:resetpass.php");
        	    }
        	    else
        	    {
        	            echo "Invalid OTP";
        	    }
        	}
        
        ?></div>
    </div>
</body>
<html>