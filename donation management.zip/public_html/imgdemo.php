<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
    <body>
        <form action="" method="post">
            <input type="file" name="aadhar">
            <input type="submit" name="sub">
             <input type="submit" name="show">
            
        </form>
    </body>
</html>
<?php
if(isset($_POST['sub']))
{
$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
$data=$_POST['aadhar'];
mysqli_query($con,"insert into img (proof) values('$data')");
}
if(isset($_POST['show']))
{
$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
$r=mysqli_query($con,"select proof from img");
while($c=mysqli_fetch_array($r))
{
    $a=$c['proof'];
}
echo "<img src='$a'></img>";

}
?>

