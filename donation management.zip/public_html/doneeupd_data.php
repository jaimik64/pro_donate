<?php
    session_start();
    require 'db.php';
    $id=$_SESSION['id'];
    $u=$_POST['n'];
    $c=$_POST['contact'];
    $ad=$_POST['ad'];
    $cty=$_POST['city'];
  
    //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="update donee set name='$u', contact='$c', address='$ad', city='$cty' where username='$id'";
    $r=mysqli_query($con,$q);
    	
    if($r)
    {
        header("location:doneep.php");
    }
    else
    {
        header("location:doneeupd.php");
    }
        
  ?>  
