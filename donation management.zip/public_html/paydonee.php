<?php session_start();?>
<html>
    <head>
        <style>
            
@import 'https://fonts.googleapis.com/css?family=Montserrat:300,400,700';

body {
  padding: 0 2em;
  font-family: Montserrat, sans-serif;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  color: #444;
  background: #eee;
}

.rwd-table {
  background: #34495E;
  color: #fff;
  border-radius: .4em;
  overflow: hidden;
  tr {
    border-color: lighten(#34495E, 10%);
  }
  th, td {
    margin: .5em 1em;
    @media (min-width: $breakpoint-alpha) { 
      padding: 1em !important; 
    }
  }
  th, td:before {
    color: #dd5;
  }
  h1 {
  font-weight: normal;
  letter-spacing: -1px;
  color: #34495E;
}
}
</style>
<?php //<form method="POST" action=""> ?>
<h3 style="color:#2F4F4F;"> Wallet Balance 
<?php 

    $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="select Balance from wallet";
    $c=mysqli_query($con,$q);
    $r=mysqli_fetch_array($c);
    echo $r['Balance'];
    ?>
    </h3>
<?php 
if(isset($_SESSION['reno']))
{
    $reno=$_SESSION['reno'];
$q3="UPDATE application SET pstatus='1' WHERE reno='$reno'";
$pck="select * from payment where RNO='$reno'";
        $pck2="select req_m from application where reno='$reno'";
       $exe=mysqli_query($con,$pck);
         $exe1=mysqli_query($con,$pck2);
         $res1=mysqli_fetch_array($exe1);
         $camt=0;
         while($res=mysqli_fetch_array($exe))
         {
             $camt=$camt+$res['amount'];
         }
         if($res1['req_m']==$camt)
         {
             mysqli_query($con,$q3);
         }
}
         ?>
   <table border="2px solid black" style="border-radius:5px; border-collapse:collapse;" cellpadding="5px" class="rwd-table">
		<tr>	
		<th>Request No</th>
		<th>Donee Id</th>
		<th>Required Money</th>
		<th>Last Date</th>
		<th>Remarks</th>
		<th>Category No</th>
		<th>Payment</th>
		</tr>
	<?php
	//$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
			$q="select*from application where status='1' AND pstatus='0'";
			$c=mysqli_query($con,$q);
		
			while($r=mysqli_fetch_array($c))
			{
				$reno=$r['reno'];				
				$req_m=$r['req_m'];	
				$last_dat=$r['last_date'];	
				$remarks=$r['remarks'];	
				$cno=$r['cat_no'];	
				$dnid=$r['dnid'];	
		?>
		<tr>
			<td><?php echo $reno?></td>
			<td><?php echo $dnid?></td>
			<td><?php echo $req_m?></td>
			<td><?php echo $last_dat?></td>
			<td><?php echo $remarks?></td>
			<td><?php echo $cno?></td>
			<td><a STYLE="color:white;" href="pay1.php?reno=<?php echo $reno;?>& amt=<?php echo $req_m;?>& doi=<?php echo $dnid;?>& cat=<?php echo $cno?>">pay</td>
		</tr>
		<?php } ?>
</table>
</form>
</body>
</html>