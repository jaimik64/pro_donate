<?php
session_start();
require 'db.php';
	$un=$_SESSION['u'];
	$name=$_SESSION['n'];
	$idp=$_SESSION['i'];
	$idpn=$_SESSION['in'];
	$nat=$_SESSION['nat'];
	$dob=$_SESSION['d'];
    $cont=$_SESSION['no'];
	$em=$_SESSION['e'];
    $add=$_SESSION['ai'];
    $cit=$_SESSION['ci'];
	$state=$_SESSION['sta'];
	$gend=$_SESSION['gend'];
	$encrypted=$_SESSION['enc'];
	$gender=$_SESSION['gender'];
	//$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
	if(isset($_POST['sub']))
	{
	        
	             if($_SESSION['otp1']==$_POST['otp'] && (time()-$_SESSION['time1'])<600)
        	    {
        	       echo $gend;
         	        if($gend=="donar")
        	       {
        	           echo "Check For Donor";
        	        	$q4="insert into donar values('$un','$name','$nat','$idp','$idpn','$dob','$gender','$encrypted','$cont','$em','$add','$cit','$state','visible')";
		            	$s=mysqli_query($con,$q4);
			            if($s)
		            	{
		            	header("location:demo.php");
				        exit();
	                    }
	                    else
	                    {
	                        echo "no";
	                    }
        	       }
        	       else if($gend=="donee")
        	       {
        	        	$q4="insert into donee values('$un','$name','$nat','$idp','$idpn','$dob','$gender','$encrypted','$cont','$em','$add','$cit','$state','','','','','')";
		            	$s=mysqli_query($con,$q4);
			            if($s)
		            	{
		            	header("location:demo.php");
				        exit();
	                    }
	                    else
	                    {
	                         echo "no";
	                    }
        	       
        	       }
        	       
        	    }
        	    else
        	    {
        	            echo "Invalid OTP";
        	    }
	    
	}
?>
<html>
    <head>
        <link rel="icon" href="heart.png">
        <title>Verification</title>
        <link rel="stylesheet" href="s2.css">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
    <body>
        <div class="box">
            <form method="post" action="">
            <span class="text-center"> Validate Email</span>
            <div class="input-container">		
		        <input type="text" name="otp" required=""/>
		        <label>SUBMIT OTP</label>
	        </div>
            <button class="btn" type="submit" name="sub" >Validate</button>
        </form>
        <a href="signup_verification_resendotp.php" style="color:white; margin-top:50px;margin-left:20px;">Resend otp?</a>
        </div>
    </body>
</html>
