<html>
<head>
       <link rel="icon" href="heart.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="index.css">
<title>
Donate  Help a Person </title>
</head>
<body>
<div class="main">
	<div class="title"> <center><h1> Donate <p> For a Better World</p></h1>
	</center>
	</div>
	<div class="menu">
    	<a href="index.php"> Home</a>
	    <a href="gallery.php">Gallery</a>
	    <a href="contact.php">Contact Us </a>
	    <a href="demo.php">Log In   </a>
	</div>
	<div class="content">


	</div>
	<div class="footer">
	    <div class="cpr">PRODONATE<br/>
	       Developed By  :  TeamDelta &copy<br/>
	        Contact : developweb@gmail.com
      </div>

	<div class="sym">
	     <img src="heart.png" height="100" width="100"><br/>
	    Your One Contribution, Can Save Many Lives
	 </div>


	</div>
</div>
</body>
</html>
