<?php
    session_start();
    require 'db.php';
    ?>
<html>
<head>    
    <link rel="icon" href="heart.png">
    <link rel="stylesheet" href="s2.css">
    <title>Donation Log</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <style>
        .menu{
            background-color:white;
            opacity:0.7;
            color:white;
            height:5%;
        }
        a{
            text-decoration:none;
            margin-left:10px;
        }
        .msg{
            font-size:20px;
        }
    </style>
</head>
<body>
    
<div class="menu">
<a href="donar.php">Home</a>
<a href="donarp.php">Profile</a>
<A HREF="donation_log.php"> Donation Log</A>
<A HREF="support.php"> Suggestion/Query?</A>
<a href="logout.php" class="lg" style="float:right">LOG OUT</a>
</div>

   <center>
       <?php
             $s=$_POST['src_date'];
            $n=$_SESSION['u'];
            //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
            $q="select * from donation where username='$n' and t_date='$s'";
            $e=mysqli_query($con,$q);
            if(mysqli_num_rows($e))
            {
        ?>
        <table border="2px solid black" style="border-radius:5px; border-collapse:collapse;margin-top:10px;" cellpadding="5px" class="rwd-table">
            <tr>
                <th>Amount</th>
                <th>OID</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
       <?php
           
            while($r=mysqli_fetch_array($e))
            {
        ?>
            <tr>
                <td><?php echo $r['t_amount']; ?></td>
                <td><?php echo $r['oid']; ?></td>
                <td><?php echo $r['t_status']; ?></td>
                <td><?php echo $r['t_date']; ?></td>
            </tr>
            <?php 
            }
            }
            else{
        ?>
            
        </table>
        
        <div class="msg">
            <?php 
                echo "You Not Make Any Donation On this Date : ".$s;
            }
            ?>
        </div>
</body>
</html>
            