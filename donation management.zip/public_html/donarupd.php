<?php
    session_start();
    require 'db.php';
    if(time()-$_SESSION['timeout']>18000)
    {
         $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
    $id=$_SESSION['id'];
    //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="select * from donar where username='$id'";
    $r=mysqli_query($con,$q);
    while($c=mysqli_fetch_array($r))
    {
        
  ?>  
  <html>
     
      <head>
          <link rel="icon" href="heart.png">
          <title> Donar Update</title>
          <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
         <link rel="stylesheet" type="text/css" href="donar_update.css">
         <style>
             .input-container input{ 
  border:0;
  border-bottom:1px solid #555;  
  background:transparent;
  width:100%;
  padding:8px 0 5px 0;
  font-size:16px;
  color:#fff;
}
         </style>
          
      </head>
       <body>
        <div class="box">
            <span class="text-center">Update Profile</span>
      <form action="donarupd_data.php" method="post">
            
            <div class="input-container">
                <lable style="font-weight:bold;">Username</lable>
                <input type="text" name="un" value="<?php echo $c['username']; ?>" disabled>
            </div>
              
              <div class="input-container">
                  <lable style="font-weight:bold;">Name<lable>
                   <input type="text" name="n" value="<?php echo $c['name']; ?>"> 
              </div>  
              <div class="input-container"> 
                  <lable style="font-weight:bold;">E-mail<lable>
                   <input type="text" name="city" value="<?php echo $c['email']; ?>"disabled> 
              </div> 
                 <div class="input-container">
                  <lable style="font-weight:bold;">Contact<lable>
                   <input type="text" name="contact" minlength="10" value="<?php echo $c['contact']; ?>"> 
               </div> 
                  
                 <div class="input-container">
                  <lable style="font-weight:bold;"> Address<lable>
                   <input type="text" name="ad" value="<?php echo $c['address']; ?>"> 
                </div>
                 <div class="input-container">
                  <lable style="font-weight:bold;">City<lable>
                   <input type="text" name="city" value="<?php echo $c['city']; ?>"> 
                </div>
                 <div class="input-container">
                  <lable style="font-weight:bold;">State<lable>
                   <input type="text" name="city" value="<?php echo $c['state']; ?>" disabled> 
                </div>
          <?php } mysqli_close($con); ?>
          <button class="btn" value="Update" name="update">Update</button>
      </form>
      </div>
      </body>
      </html>