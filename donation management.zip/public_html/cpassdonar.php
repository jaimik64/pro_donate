<?php
session_start();
require 'db.php';
if(time()-$_SESSION['timeout']>18000)
    {
         $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
    if(isset($_POST['subb']))
    {
        $id=$_GET['id'];
        $q="select * from donar where username='$id'";
        $r=mysqli_query($con,$q);
        $c=mysqli_fetch_array($r);
        if(password_verify($_POST['oldp'],$c['password'])==1)
        {
            if($_POST['newp']==$_POST['rps'])
            {
                $en=password_hash($_POST['newp'],PASSWORD_DEFAULT);
                $q="UPDATE donee SET password='$en' WHERE username='$id'";
                $r=mysqli_query($con,$q);
                if($r)
                {
                    echo "password updated successfully";
                }
                else
                {
                    echo "something went wrong";
                }
            }
            else
            {
                echo"password dosen't match";
            }
        }
        else
        {
            echo " old password is wrong";
        }
        }
?>
<html>
   
        <head>
                    <title>Password</title>
                    <link rel="icon" href="heart.png">
                      <link rel="stylesheet" type="text/css" href="s2.css">
                    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        </head>
         <body>
              <div class="menu" style="background-color:#ffffff;width:100%;opacity:0.7;">
                  <a href="donar.php">Home</a>
<a href="donarp.php">Profile</a>
<A HREF="donation_log.php"> Donation Log</A>
<A HREF="support.php"> Suggestion/Query?</A>
<a href="logout.php" class="lg" style="float:right">  LOG OUT</a>&nbsp;
<A HREF="donarp.php" > Back  </A>

</div>
             <div class="box">
    <form action="" method="post">
        
     <div class="input-container">
    OLD PASSWORD:<input type="password" name="oldp"><br>
    </div>
     <div class="input-container">
     NEW PASSWORD:<input type="password" name="newp"  minlength="8"><br>
     </div>
      <div class="input-container">
     RE-ENTER PASSWORD:<input type="password" name="rps"  minlength="8"><br>
     </div>
     <input type="submit" name="subb">

    </form>
    </div>
    </body>
</html>