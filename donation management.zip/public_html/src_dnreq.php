<?php 
    session_start();
    require 'db.php';
    $d=$_SESSION['u'];
    $value=$_POST['src'];
    
    //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="select * from application where dnid='$d' and (req_m='$value') ";
    $e=mysqli_query($con,$q);
?>
<html>
<head>
    <link rel="icon" href="heart.png">
    <link rel="stylesheet" href="s2.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <title>View Request</title>
   <style>
                        
@import 'https://fonts.googleapis.com/css?family=Montserrat:300,400,700';

body {
  padding: 0 2em;
  font-family: Montserrat, sans-serif;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  color: blue;
  background: #eee;
}

.rwd-table {
  background: #34495E;
  color: #fff;
  border-radius: .4em;
  overflow: hidden;
  border-color:white;
  border-collapse:collapse;
  tr {
    border-color: lighten(#34495E, 10%);
  }
  th, td {
    margin: .5em 1em;
    @media (min-width: $breakpoint-alpha) { 
      padding: 1em !important; 
    }
  }
  th, td:before {
    color: #dd5;
  }
  h1 {
  font-weight: normal;
  letter-spacing: -1px;
  color: #34495E;
}
}
th
{
    background:#b9c9c3;
    color:blue;
}
a{
    text-decoration:none;
    margin-left:5px;
}
.msg{
    font-size:20px;
    text-align:center;
}
        </style>
        <link rel="stylesheet" type="text/css" href="s2.css">
    </head>
    <body>
    <div class="menu" style="background-color:#ffffff;width:100%;opacity:0.7;">
<a href="donee.php">HOME</a>
<a href="doneep.php">PROFILE</a>
<a href="viewreq.php">VIEW REQUEST</a>
<a href="support.php">SUPPORT</a>
<a href="logout.php" class="lg1" style="float:right;">LOG OUT</a>
</div>
<?php 
    if(mysqli_num_rows($e))
    {
?>
<center>
<table style="margin-top:10px;" border="2">
    <tr>
        <th>Request No</th>
        <th>Required Money</th>
        <th>Last Date</th>
        <th>Remarks</th>
        <th>Category No </th>
        <th>User Name</th>
    </tr>
    <?php
    
    while($r=mysqli_fetch_array($e))
    { 
    ?>
    <tr>
        <td><?php echo $r['reno']; ?></td>
        <td><?php echo $r['req_m']; ?></td>
        <td><?php echo $r['last_date']; ?></td>
        <td><?php echo $r['remarks']; ?></td>
        <td><?php echo $r['cat_no']; ?></td>
        <td><?php echo $r['dnid']; ?></td>
    </tr>
    <?php
    }
    }
    else{
    ?>
</table><div class="msg">
    <?php
        echo "Sorry No Request Based On Your Input";
    }
    ?></div>
</center>
</body>
</html>