<?php
 	session_start();
 	  if(time()-$_SESSION['timeout']>18000)
    {
        $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
 	$id=$_SESSION['id'];
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\SMTP;
		use PHPMailer\PHPMailer\Exception;

		// Load Composer's autoloader
		require 'vendor/autoload.php';
		require 'db.php';
?>
<html>
        <head>
            <link rel="stylesheet" type="text/css" href="s2.css">
            <link rel="icon" href="heart.png">
            <title>Suggestion Or Query</title>
            <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
            <style>
                .btn1{
                	color:#fff;
                	background-color:#e74c3c;
                	outline: none;
                    border: 0;
                	padding:10px 20px;
                	text-transform:uppercase;
                	margin-top:20px;
                	margin-left:200px;
                	border-radius:2px;
                	position:relative;
                }
                .menu{
                    height:5%;
                    background-color:white;
                    color:blue;
                    margin-bottom:50px;
                    opacity:0.7;
                }
                a{
                    padding-left:10px;
                    text-decoration:none;
                }
            </style>
        </head>
        <body>
            <?php if($_SESSION['usertype']=="donee"){?>
                                      <div class="menu" style="background-color:#ffffff;width:100%;opacity:0.7;">
<a href="donee.php">HOME</a>
<a href="doneep.php">PROFILE</a>
<a href="viewreq.php">VIEW REQUEST</a>
<a href="support.php">SUPPORT</a>
<a href="logout.php" class="lg1" style="float:right;">LOG OUT</a>
</div>
<?php } else { ?>
        <div class="menu">
            <a style="color:blue;" href="donar.php">Home</a>
            <a style="color:blue;"href="donarp.php">Profile</a>
            <a style="color:blue;" HREF="donation_log.php"> Donation Log</A>
            <a style="color:blue;" HREF="support.php">Suggestion/Query?</A>
            <a style="padding-left:60%" href="logout.php">Log Out</a>
        </div>
<?php } ?>
        <div class="box" style="border-radius:40px;">
        <form method="post" action="">
            <span classs="text-center">MESSAGE:</span>
            <div class="input-container">
            <textarea cols="60" rows="8" name="message"></textarea>
            </div>
            <button class="btn1" type="submit" name="sub" value="send">Send</button>
            
        </form>
        </div>
    </body>
</html>
<?php
    if(isset($_POST['sub'])&&($_POST['message']))
    {
        //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
        $q="select email from donar where username='$id'";
        $r=mysqli_query($con,$q);
        $c=mysqli_fetch_array($r);
        $emi=$c['email'];
        $b=$_POST['message'];
	
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
	

	try{	// Instantiation and passing `true` enables exceptions
		$mail = new PHPMailer(true);

	
			//Server setting
			// Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   ='prodonate007@gmail.com';                     // SMTP username qmuzwncy@gmail.com
			$mail->Password   = 'Jaimik#64';                              // SMTP password
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('from@example.com', 'ProDonate');    // Add a recipient
			$mail->addAddress('nandraj167@gmail.com');               // Name is optional
			$mail->addAddress('jaimikc@gmail.com');
			$mail->addAddress('prodonate007@gmail.com');

			// Attachments
			//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			// Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'message sent from  '.$emi;
			$mail->Body    = $b;
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			if($mail->send())
			{
			    echo 'MESSAGE SENT';
			    //header("location:donar.php");
			}
	}
	catch (phpmailerException $e){
	    echo $e->errorMessage();
	}
	catch(Exception $e){
	    echo $e->getMessage();
	}
    }
?>