<?php session_start(); ?>
<html>
<body>
<div style="background-color:yellow;height:20px"><a href="catagory.php">create catagory</a><div>
<div style="background-color:yellow;height:20px"><a href="viewreq.php">view request</a><div>
<?php
	echo "welcome  ".$_SESSION['id'];
	
?>
</body>
</html>