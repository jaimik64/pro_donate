<?php
    require 'db.php';
 //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
  $p=$_GET['user'];
  $r=$_GET['req'];
  $q="delete from application where dnid='$p' AND reno='$r'";
  $r=mysqli_query($con,$q);
  if($r)
  {
      header("location:viewreq.php");
      exit();
  }
  ?>