    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <style>
            
@import 'https://fonts.googleapis.com/css?family=Montserrat:300,400,700';

body {
  padding: 0 2em;
  font-family: Montserrat, sans-serif;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  color: #444;
  background: #eee;
}
.menu{
    height:5%;
    font-size:20px;
    opacity:0.7;
    background-color:white;
    text-decoration:none;
    
}
.rwd-table {
  background: #34495E;
  color: #fff;
  border-radius: .4em;
  overflow: hidden;}
  tr {
    border-color: lighten(#34495E, 10%);
  }
  th, td {
    margin: .5em 1em;
    @media (min-width: $breakpoint-alpha) { 
      padding: 1em !important; 
    }
  }
  th, td:before {
    color: #dd5;
  }
  h1 {
  font-weight: normal;
  letter-spacing: -1px;
  color: #34495E;}

a{
    color:blue;
    text-decoration:none;
    margin-left:10px;
}
@media screen and (max-width:360px)
{
    .input-container input{
        width:100%;
    }
    .menu{
        height:4%;
    }
}
</style>
<link rel="icon" href="heart.png">
<link rel="stylesheet" href="s2.css">
<link rel="stylesheet" href="">
<title>Donation Log</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" /></head>
<body>
    
<div class="menu">
<a href="donar.php">Home</a>
<a href="donarp.php">Profile</a>
<A HREF="donation_log.php"> Donation Log</A>
<A HREF="support.php"> Suggestion/Query?</A>
<a href="logout.php" class="lg" style="float:right">LOG OUT</a>
</div>
<form action="src_donationlog.php" method="post">
    <div class="input-container" style="width:15%;">
    <input type="date" name="src_date" placeholder="Select Date" style="margin-bottom:0%;">
    </div>
    <button class="btn" style="margin-top:0%;"name="submit" value="search">Search</button>
</form>
   <center>
        <table border="2px solid black" style="border-radius:5px; border-collapse:collapse;margin-top:10px;" cellpadding="5px" class="rwd-table">
            <tr>
                <th>Amount</th>
                <th>OID</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
            <tr>
<?php
    session_start();
    require 'db.php';
	if($_SESSION['id']==true)
	{	}
	else
	{
	    header("location:demo.php");
	    exit();
	}
    $id=$_SESSION['id'];
    
    // $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    $q="select * from donation where username='$id'";
    $r=mysqli_query($con,$q);
    
    while($c=mysqli_fetch_array($r))
    {
        $amt=$c['t_amount'];
        $o=$c['oid'];
        $t=$c['t_status'];
        $d=$c['t_date'];
    ?>
                <td><?php echo $amt;  ?></td>
                <td><?php echo $o; ?></td>
                <td><?php echo $t; ?></td>
                <td><?php echo $d; ?></td>
            </tr>
                <?php }
                $_SESSION['u']=$id;
                ?>
        </table></center>
    </body>
</html>