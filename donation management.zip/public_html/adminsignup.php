<?php 
    session_start();
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
        <style>
        *{
            box-sizing:border-box;
        }
            body{
                font-family:'Nunito';
            }
            h1{
                text-align:center;color:black;width:30.4%;height:10%;padding-top:1%;margin-bottom:0%;font-family:consolas;background-color:lightblue;border-radius:10px;}
           .form{ text-align:center;color:black;width:30%;height:60%;font-family:consolas;border:2px solid black;padding-top:2.6%;border-radius:10px; }
           button{
               width:100px;
                
           }
          input{ background-color: #eee;
	            border: none;
            	padding: 5px 15px;
        	    margin: 2px 0;
        	    width: 85%;
          }
          textarea{
              background-color: #eee;
	            border: none;
            	padding: 8px 15px;
        	    margin: 4px 0;
        	    width: 85%;
        	    height:8%;
          }
             .btype {
  display: inline-block;
  border-radius: 4px;
  background-color: #87CEFA;
  border: none;
  color: black;
  text-align: center;
  font-size: 12px;
  padding: 5px;
  width: 100px;
  height:25px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  font-weight:bold;
}

.btype span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.btype span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.btype:hover span {
  padding-right: 25px;
}

.btype:hover span:after {
  opacity: 1;
  right: 0;
}
        </style>
    </head>
<body>
	<form method="POST" action="adminsignup_data.php">
	<center><h1>SIGN UP</H1></center>
	<center><div class="form">
		<input type="text" name="uid" placeholder="Username" style="border-radius:5px;" required><br><BR>
		<input type="text" name="name" placeholder="Name" style="border-radius:5px;"><br><BR>
		<input type="password" name="pas" placeholder="Password" style="border-radius:5px;"><br><BR>
		<input type="password" name="rpas" placeholder="Re-Enter Password" style="border-radius:5px;"><br><BR>
		<input type="NUMBER" name="num"  placeholder="Contact NO" style="border-radius:5px;" maxlenth="10" minlenth="10" required><br><BR>
		<input type="EMAIL" name="emi" placeholder="Email" style="border-radius:5px;" required><br><BR>
		<textarea name="add" rows="5" cols="20" placeholder="Address" style="border-radius:5px;" required></textarea><br>
		<input type="text" name="city" placeholder="City" style="border-radius:5px;" required><br><br>
		<button class="btype" name="sub" value="SIGN UP" style="background-color:lightblue;font-family:verenda;"><span>Sign UP</span></button><br>
	</div></center>
	</form>
		<?php	
			//session_start();
			if(isset($_SESSION['st']))
			{	
				echo "<center>";
				echo "TRY ANOTHER USERNAME";
				echo "</center>";
				unset($_SESSION['st']);
			}	
			if(isset($_SESSION['emi']))
			{	
				echo "<center>";
				echo "TRY ANOTHER EMAIL";
				echo "</center>";
				unset($_SESSION['emi']);
			}
			else if(isset($_SESSION['err']))
			{	
				echo "<center>";
				echo "PLEASE ENTER CORRECT PASSWORD";
				echo "</center>";
				unset($_SESSION['err']);
			}	
			else if(isset($_SESSION['eigc']))
			{	
				echo "<center>";
				echo "PASSWORD MUST ATLEAST 8 CHARACTERS LONG";
				echo "</center>";
				unset($_SESSION['eigc']);
			}
		?>
	</body>
	</html>