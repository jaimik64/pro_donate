<?php
    session_start();
    require 'db.php';
?>
<html>
    <head>
        <link rel="stylesheet" href="s2.css">
        <link rel="icon" href="heart.png">
        <style>
            .sp{
                    margin-top:20px;
            }
            a{
                color:white;
            }
            .error{
                color:white;
            }
            .radio
            {
                size:32px;
                margin-bottom:25px;
                margin-top:-25%; 
                position:relative; 
                margin-left:15%;
                width:15px;
                height: 15px; 
            }
        </style>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Log In</title>
    </head>
    <body>
        <div class="box" style="border-radius:40px;">
	        <form method="post" action="check.php">
		        <span class="text-center">login</span>
		        <label required><input type="radio" name="gen" style="size:25px;" class="radio"value="donar" checked>Donor</label>
		         <label><input type="radio" name="gen" class="radio" value="donee">Donee</label><br/>
	        
	            <div class="input-container">
		            <input type="text" name="uid" required=""/>
		            <label>UserName</label>		
	            </div>
	            <div class="input-container">		
		            <input type="password" name="pas" id="pas1"required=""/>
		            <label>Password</label>
	            </div>
	            <input type="checkbox"  onclick="mf()"  class="sp">Show Password<br/>
    	<script>
	        function mf(){
	            var x=document.getElementById("pas1");
	            if(x.type=="password"){
	                x.type="text";}
	            else{
	                x.type="password";}
	       }
	    </script><br/>
	        <a style="color:white; margin-top:40px;margin-left:80px;" href="forgotpass.php">Forgot Password?</a><br/>
	        <a  style="color:white;margin-top:20px; position:relative; margin-left:80px; " href="forgotus.php">Forgot username</a><br/>
		
		    <button class="btn" style="position:relative; margin-left:35%;" type="submit" name="sub"><span>Log In</span></button><br/> 
        </form>	
<?php	
		if(isset($_SESSION['sel']))
		{
		    echo "Please Select Type Of User";
		    unset($_SESSION['sel']);
		    echo "<br/>";
		    echo "<br/>";
		}
			if(isset($_SESSION['st']))
			{
				echo " WRONG USERNAME OR PASSWORD";
				unset($_SESSION['st']);
			}	
				if(isset($_SESSION['loginagain']))
			{
				echo "SESSION TIMEOUT LOGIN AGAIN";
				unset($_SESSION['loginagain']);
			}
			
			
			//clearing signup from sessions.
				unset($_SESSION['u']);
				unset($_SESSION['p']);
				unset($_SESSION['rp']);
    			unset($_SESSION['d']);
		    	unset($_SESSION['ci']);
    			unset($_SESSION['e']);
				unset($_SESSION['nn']);
				unset($_SESSION['in']);
				unset($_SESSION['i']);
                unset($_SESSION['n']);
                unset($_SESSION['sta']);
              
      
?>	
<div style=" margin-left:50px; margin-top:20px;"><a  style="color:white;" href="signup.php">Create Account</a></div>
</div>

</body>
</html>