<?php
    session_start();
    require 'db.php';
  
	if(isset($_SESSION['id']) && $_SESSION['usertype']=="donar")
	{
	   
	echo "welcome  ".$_SESSION['id'];
	}
	else
	{
	    header("location:demo.php");
	    exit();
	}
	$id=$_SESSION['id'];
?>
<html>
<body>
<head>
        <link rel="icon" href="heart.png">
        <title>Welcome Donor</title>
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
        <link rel="stylesheet" type="text/css" href="donar.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
</head>
<body>
<div class="menu">
<a href="donarp.php">Profile</a>
<A HREF="donation_log.php"> Donation Log</A>
<A HREF="support.php">Suggestion/Query?</A>
<a href="logout.php" style="float:right;">LOG OUT</a>
</div>
<form method="post" action="donate.php">
<?php
	//echo "welcome  ".$_SESSION['id'];

	$q="select * from catagory";
	$c=mysqli_query($con,$q);
	while($r=mysqli_fetch_array($c))
	{
	$n=$r['cat_name'];
	$l=$r['cat_amt'];
	if($l<1000)
	{
?>

 <button name="cat" value="<?php echo $n;?>" style="background-color:red"><?php echo $n;?></button>
     <?php $_SESSION['n']=$n; } else{?>
     <button name="cat" value="<?php echo $n;?>"><?php echo $n;?></button>
<?php echo"   ";}?>
<?php }?>
</form>
<br>

</body>
</html>