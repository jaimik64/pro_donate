<?php
    session_start();
    require 'db.php';
?>
<html>
<head>

    <link rel="stylesheet" type="text/css" href="s2.css" >
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<STYLE>

    .sp{
        margin-top:20px;
    }
    a{
        color:white;
    }
    .error{
        color:white;
    }
</STYLE>
</head>
<body>
<div class="box" style="height:45%; border-radius:20px;">
	<form method="POST" action="check.php">
	<span class="text-center">login</span>
	<div class="input-container">
	    <input type="text"  onfocus="this.value=''" name="uid"  required>
	    <label>UserName</label>
	</div>
	<div class="input-container">
		      <input type="Password" name="pas"  required>
		      <label>Password</label>
    </div>
		<div class="fp"><a href="forgotpass.php"  >Forgot Password?</a></div>
		<div class="fp"><a href="forgotus.php"  >Forgot username?</a></div>
		
		<button class="btn" style="margin-left:50pxp;"type="submit" name="sub">Log In</button>
		<div class="sp"><a href="adminsignup.php">SIGN  UP?</a></div>
			<div class="error">
			<?php	
		
    			if(isset($_SESSION['st']))
    			{
    				echo "<center>";
    				echo " WRONG USERNAME OR PASSWORD";
    				echo "</center>";
    				unset($_SESSION['st']);
    			}	
    			    //clearing signup form sessions
    				    unset($_SESSION['u']);
    					unset($_SESSION['n']);
    					unset($_SESSION['p']);
    					unset($_SESSION['rp']);
    					unset($_SESSION['nn']);
    					unset($_SESSION['e']);
    					unset($_SESSION['ci']);
    					unset($_SESSION['ai']);
	            ?></div>
		</div>
</form>
</body>
</html>