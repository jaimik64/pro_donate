<?php session_start();?>
<html>
<head>
    <link rel="icon" href="heart.png">
    <link rel="stylesheet" href="s2.css" type="text/css">
        
    <title>View Request</title>
   <style>
                        
@import 'https://fonts.googleapis.com/css?family=Montserrat:300,400,700';

body {
  padding: 0 2em;
  font-family: Montserrat, sans-serif;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  color: #444;
  background: #eee;
}

.rwd-table {
  background: #34495E;
  color: #fff;
  border-radius: .4em;
  overflow: hidden;
  border-color:white;
  border-collapse:collapse;
  tr {
    border-color: lighten(#34495E, 10%);
  }
  th, td {
    margin: .5em 1em;
    @media (min-width: $breakpoint-alpha) { 
      padding: 1em !important; 
    }
  }
  th, td:before {
    color: #dd5;
  }
  h1 {
  font-weight: normal;
  letter-spacing: -1px;
  color: #34495E;
}
}
th
{
    background:#b9c9c3;
}
a{
    text-decoration:none;
    margin-left:5px;
}
::placeholder{
    color:white;
}
        </style>
        <link rel="stylesheet" type="text/css" href="s2.css">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    </head>
    <body>
    <div class="menu" style="background-color:#ffffff;width:100%;opacity:0.7;">
<a href="donee.php">HOME</a>
<a href="doneep.php">PROFILE</a>
<a href="viewreq.php">VIEW REQUEST</a>
<a href="support.php">SUPPORT</a>
<a href="logout.php" class="lg1" style="float:right;">LOG OUT</a>
</div>
<form method="post" action="src_dnreq.php">
    <div class="input-container" style="width:20%;margin-top:1%;">
        <input type="text" name="src" placeholder="Enter Amount / bank name/Account No">
    </div>
    <button class="btn" style="margin:0%;">Search</button>
</form>
<form method="POST" action="">
<h3 style="color:white;"> YOUR REQUESTS</h3>
<table class="rwd-table" border="2px solid">
		<tr>	
		<th>request_no</th>
		<th>required_money</th>
		<th>last_date</th>
		<th>remarks</th>
		<th>category no</th>
		<th>username</th>
		<th>idproof</th>
		<th>passbook</th>
		<th>delete</th>
		</tr>
		<?php
		    $d=$_SESSION['id'];
	        require 'db.php';
	        //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
			$q="select*from application where status='0' AND dnid='$d'";
			$c=mysqli_query($con,$q);
	
			while($r=mysqli_fetch_array($c))
			{
				$reno=$r['reno'];				
				$req_m=$r['req_m'];	
				$last_dat=$r['last_date'];	
				$remarks=$r['remarks'];	
				$cno=$r['cat_no'];	
				$dnid=$r['dnid'];	
		?>
		<tr>
			<td><?php echo $reno?></td>
			<td><?php echo $req_m?></td>
			<td><?php echo $last_dat?></td>
			<td><?php echo $remarks?></td>
			<td><?php echo $cno?></td>
			<td><?php echo $dnid?></td>
			<td><a href="view1.php?req=<?php echo $reno?>&user=<?php echo $dnid?>">VIEW</a></td>
			<td><a href="view2.php?req=<?php echo $reno?>&user=<?php echo $dnid?>">VIEW</a></td>
			<td><a href="delete.php?req=<?php echo $reno?>&user=<?php echo $dnid?>">DELETE</a></td>
		</tr>
		<?php } ?>
</table>
<h3 style="color:white;">ACCEPTED REQUESTS</h3>
<table class="rwd-table" border="2px solid">
		<tr>	
		<th>request no</th>
		<th>required money</th>
		<th>last_date</th>
		<th>remarks</th>
		<th>category no</th>
		<th>username</th>
		<th>idproof</th>
		<th>passbook</th>
		<th>Recieved Payment</th>
		</tr>
		<?php
		    $d=$_SESSION['id'];
	        $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
			$q="select*from application where status='1' AND dnid='$d'";
			$c=mysqli_query($con,$q);
			while($r=mysqli_fetch_array($c))
			{
				$reno=$r['reno'];				
				$req_m=$r['req_m'];	
				$last_dat=$r['last_date'];	
				$remarks=$r['remarks'];	
				$cno=$r['cat_no'];	
				$dnid=$r['dnid'];	
		?>
		<tr>
			<td><?php echo $reno?></td>
			<td><?php echo $req_m?></td>
			<td><?php echo $last_dat?></td>
			<td><?php echo $remarks?></td>
			<td><?php echo $cno?></td>
			<td><?php echo $dnid?></td>
			<td><a href="view1.php?req=<?php echo $reno?>&user=<?php echo $dnid?>" style="color:white;">VIEW</a></td>
			<td><a href="view2.php?req=<?php echo $reno?>&user=<?php echo $dnid?>" style="color:white;">VIEW</a></td>
			<td><a href="rpay.php?req=<?php echo $reno?>" style="color:white;">VIEW</a></td>
		</tr>
		<?php } 
		$_SESSION['u']=$d;
		?>
</table>
</form>
</body>
</html>