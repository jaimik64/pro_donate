<?php
$to="fakir4913@gmail.com";
$s="tankuyeinn";
$m="rivan";
$h="From:nandraj167@gmail.com";

if(mail($to,$s,$m,$h))
	echo "sent";
else
	echo "error";
?>