<?php
    $host="localhost";
    $user="id11970969_root";
    $password="root007";
    $db="id11970969_dms";
    
    $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    if($con){}
    else{
        echo "Connection Error";
    }
?>