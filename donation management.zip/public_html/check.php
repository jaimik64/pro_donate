<?php
date_default_timezone_set("Asia/Calcutta");
session_start();
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\SMTP;
		use PHPMailer\PHPMailer\Exception;
	require 'vendor/autoload.php';
	require 'db.php';

if(empty($_POST['gen']))
	{
		$_SESSION['sel']=false;
	
		header("location:demo.php");
	}
$u=$_POST['uid'];
$p=$_POST['pas'];//input password
$g=$_POST['gen'];

if($g=="donar")
{
    
	$q="select*from donar where username='$u'";
	$c=mysqli_query($con,$q);
	$r=mysqli_fetch_array($c);
	$_SESSION['mrms']=$r['gender'];
		if($r['username']==$u && password_verify($p,$r['password'])==1)
		{
			$_SESSION['id']=$u;
			
			$_SESSION['timeout']=time();
$_SESSION['usertype']="donar";
			$d=date("h:i:s");
			smail($r['email'],$d);
			header("location:donar.php");
			exit();
		}
		else
		{
			$_SESSION['st']=false;
		
			header("location:demo.php");
			exit();
		}
	
}
else if($g=="donee")
{
	$q1="select*from donee where username='$u'";
	$c1=mysqli_query($con,$q1);
	$r=mysqli_fetch_array($c1);
	{
		if($r['username']==$u && password_verify($p,$r['password'])==1)
		{
			$_SESSION['id']=$u;
		    $_SESSION['usertype']="donee";
			$_SESSION['timeout']=time();
			$d=date("h:i:s");
			smail($r['email'],$d);
			header("location:donee.php");
			exit();
		}
		else
		{
			$_SESSION['st']=false;
			echo "Donee condition false";
			header("location:demo.php");
			exit();
		}
	}
}

	
	
	function smail($m,$d)
	{
	
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
	

		// Instantiation and passing `true` enables exceptions
		try
		{$mail = new PHPMailer(true);

	
			//Server setting
			// Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   ='prodonate007@gmail.com';                     // SMTP username qmuzwncy@gmail.com
			$mail->Password   = 'Jaimik#64';                               // SMTP password Mail@123
			$mail->SMTPSecure = tls;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('from@example.com', 'ProDonate');    // Add a recipient
			$mail->addAddress($m);               // Name is optional
			

			// Attachments
			//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			// Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'Alert';
			$mail->Body    = 'Your account was accessed on '.$d
			               ;
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

		$mail->send();
		}
catch (phpmailerException $e) {
  echo $e->errorMessage(); //Pretty error messages from PHPMailer
} catch (Exception $e) {
  echo $e->getMessage(); //Boring error messages from anything else!
}
	}
?>
	