<?php
    session_start();
   require 'db.php';
   
      if(time()-$_SESSION['timeout']>18000)
    {
         $_SESSION['loginagain']=false;
        header("location:demo.php");
	    exit();
    }
	if($_SESSION['id']==true && $_SESSION['usertype']=="donee")
	{
	echo "welcome  ".$_SESSION['id'];
	}
	else
	{
	    header("location:demo.php");
	}
?>
<html>
<head>
    <link rel="icon" href="heart.png">
    <title>Donee Home Page</title>
        <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Nunito" />
        <link rel="stylesheet" type="text/css" href="donee.css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
</head>
<body>
<div class="menu">
<a href="doneep.php">PROFILE</a>
<a href="viewreq.php">VIEW REQUEST</a>
<a href="support.php">SUPPORT</a>
<a href="logout.php" class="lg1" style="float:right">LOG OUT</a>
</div>
<p>To Make Request, Click Below Button</p>
<?php
	//echo "welcome  ".$_SESSION['id'];
//$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
	$q="select * from catagory";
	$c=mysqli_query($con,$q);
	while($r=mysqli_fetch_array($c))
	{
	$n=$r['cat_name'];
?>

<button onClick="window.location.href='req.php';"><?php echo $n;?></button><?php echo"   ";?>
<?php }?>
<br>

</body>
</html>