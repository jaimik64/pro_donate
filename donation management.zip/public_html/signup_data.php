<?php
	session_start();
	require 'db.php';
	
	ob_start();
	$_SESSION['u']=$_POST['uid'];
	$_SESSION['n']=$_POST['name'];
	$_SESSION['i']=$_POST['idp'];
	$_SESSION['in']=$_POST['idpn'];
	$_SESSION['nat']=$_POST['nat'];
	$_SESSION['d']=$_POST['dob'];
	$_SESSION['p']=$_POST['pas'];
	$_SESSION['rp']=$_POST['rpas'];
	$_SESSION['no']=$_POST['num'];
	$_SESSION['e']=$_POST['emi'];
	$_SESSION['ai']=$_POST['add'];
	$_SESSION['ci']=$_POST['city'];
	$_SESSION['nn']=$_POST['num'];
	$_SESSION['sta']=$_POST['state'];
	$_SESSION['gend']=$_POST['gen'];
    $_SESSION['gender']=$_POST['genn'];
 	if(empty($_POST['gen']))
	{
		$_SESSION['sel']=false;
		header("location:signup.php");
		exit();
	}
	$un=$_POST['uid'];
	$name=$_POST['name'];
	$nat=$_POST['nat'];
	$idp=$_POST['idp'];
	$idpn=$_POST['idpn'];
	$gend=$_POST['gen'];
	$dob =$_POST['dob'];
	$ps=$_POST['pas'];
	$rps=$_POST['rpas'];
	$cont=$_POST['num'];
	$em=$_POST['emi'];
	$gen=$_POST['gen'];
	$add=$_POST['add'];
	$cit =$_POST['city'];
	$state =$_POST['state'];
	$encrypted=password_hash($ps,PASSWORD_DEFAULT);
	$_SESSION['enc']=$encrypted;
//$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
$q5="select * from donee where username='$un'";
$v=mysqli_query($con,$q5);
$re=mysqli_fetch_array($v);
$q6="select * from admin where username='$un'";
$v1=mysqli_query($con,$q6);
$re1=mysqli_fetch_array($v1);

	if($gen=="donar")
    {
		$q2="select * from donar where username='$un'";
		$c2=mysqli_query($con,$q2);
		$r2=mysqli_fetch_array($c2);
		if($un==$r2['username'])
		{
			$_SESSION['st1']=false;
			header("location:signup.php");
			exit();
		}
		
		$q3="select * from donar where email='$em'";
	    $c3=mysqli_query($con,$q3);
		$r3=mysqli_fetch_assoc($c3);
		if($em==$r3['email'])
		{
		   	$_SESSION['emi']=false;
			header("location:signup.php");
			exit();
		}
			$q31="select * from admin where email='$em'";
	    $c31=mysqli_query($con,$q31);
		$r31=mysqli_fetch_assoc($c31);
		if($em==$r31['email'])
		{
		   	$_SESSION['emi']=false;
			header("location:signup.php");
			exit();
		}
		$que="select * from donar where contact='$cont'";
	    $cue=mysqli_query($con,$que);
		$rue=mysqli_fetch_assoc($cue);
		if($cont==$rue['contact'])
		{
		   	$_SESSION['c']=false;
			header("location:signup.php");
			exit();
		}
			$que1="select * from donee where contact='$cont'";
	    $cue1=mysqli_query($con,$que1);
		$rue1=mysqli_fetch_assoc($cue1);
		if($cont==$rue1['contact'])
		{
		   	$_SESSION['c']=false;
			header("location:signup.php");
			exit();
		}
			$que2="select * from admin where contact='$cont'";
	    $cue2=mysqli_query($con,$que2);
		$rue2=mysqli_fetch_assoc($cue2);
		if($cont==$rue2['contact'])
		{
		   	$_SESSION['c']=false;
			header("location:signup.php");
			exit();
		}

		else if($ps==$rps)
		{
			if(empty($ps))
			{
				$_SESSION['ps']=false;
				header("location:signup.php");
				exit();
			}
			else if(strlen($cont)>10||strlen($cont)<10||$cont=="")
			{
				$_SESSION['cont']=false;
				header("location:signup.php");
					exit();
			}
			else if(strlen($ps)<=7)
			{
				$_SESSION['eigc']=false;
				header("location:signup.php");
					exit();
			}
			else if($idp=="Aadhar" && strlen($idpn)!=12)
			{
			    $_SESSION['idp1']=false;
			    header("location:signup.php");
			    	exit();
			}
            else if($idp=="Pancard" && strlen($idpn)!=10)
			{
			    $_SESSION['idp2']=false;
			    header("location:signup.php");
			    	exit();
			}
			
			else if($un==$re1['username'])
			{
			    	$_SESSION['st1']=false;
			        header("location:signup.php");
			        	exit();
			}
				else if($un==$re['username'])
			{
			    	$_SESSION['st1']=false;
			        header("location:signup.php");
			        	exit();
			}
			else
			{
			
	                	/*$q4="insert into donar values('$un','$name','$nat','$idp','$idpn','$dob','$gend','$encrypted','$cont','$em','$add','$cit','$state')";
		            	$s=mysqli_query($con,$q4);
			            if($s)
		            	{
		            	header("location:demo.php");
				        exit();
	                    }*/
	                    header("location:signup_verification.php");
	                    exit();
	            

			}
		}
		else
		{
			$_SESSION['err']=false;
			header("location:signup.php");
				exit();
		}
		
	}
		
		
		
	else if($gen=="donee")
	{
		$q2="select * from donee where username='$un'";
		$c2=mysqli_query($con,$q2);
		$r2=mysqli_fetch_array($c2);
		if($un==$r2['username'])
		{
			$_SESSION['st1']=false;
			header("location:signup.php");
			exit();
		}
		
		$q3="select * from donee where email='$em'";
	    $c3=mysqli_query($con,$q3);
		$r3=mysqli_fetch_assoc($c3);
		if($em==$r3['email'])
		{
		   	$_SESSION['emi']=false;
			header("location:signup.php");
				exit();
		}
		$que="select * from donee where contact='$cont'";
	    $cue=mysqli_query($con,$que);
		$rue=mysqli_fetch_assoc($cue);
		if($cont==$rue['contact'])
		{
		   	$_SESSION['c']=false;
			header("location:signup.php");
			exit();
		}

		else if($ps==$rps)
		{
			if(empty($ps))
			{
				$_SESSION['ps']=false;
				header("location:signup.php");
					exit();
			}
			else if(strlen($cont)>10||strlen($cont)<10||$cont=="")
			{
				$_SESSION['cont']=false;
				header("location:signup.php");
					exit();
			}
			else if(strlen($ps)<=7)
			{
				$_SESSION['eigc']=false;
				header("location:signup.php");
					exit();
			}
            else if($idp=="Aadhar" && strlen($idpn)!=12)
			{
			    $_SESSION['idp1']=false;
			    header("location:signup.php");
			    exit();
			}
            else if($idp=="Pancard" && strlen($idpn)!=10)
			{
			    $_SESSION['idp2']=false;
			    header("location:signup.php");
			    	exit();
			}
				else if($un==$re1['username'])
			{
			    	$_SESSION['st1']=false;
			        header("location:signup.php");
			        	exit();
			}
				else if($un==$re['username'])
			{
			    	$_SESSION['st1']=false;
			        header("location:signup.php");
			        	exit();
			}
			
			else
		        {
	                /*	$q4="insert into donee values('$un','$name','$nat','$idp','$idpn','$dob','$gend','$encrypted','$cont','$em','$add','$cit','$state')";
		            	$s=mysqli_query($con,$q4);
			            if($s)
		            	{
		            	header("location:demo.php");
				        exit();
	                    }*/
	                   	header("location:signup_verification.php");
	                   	exit();
		        }

		}
		else
		{
			$_SESSION['err']=false;
			header("location:signup.php");
				exit();
		}
		
	}
//	else
//	{
	    //	$_SESSION['empform']=false;
		//	header("location:signup.php");
//	}
?>


