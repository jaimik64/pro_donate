<?php
		
		session_start();
		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\SMTP;
		use PHPMailer\PHPMailer\Exception;

		// Load Composer's autoloader
		require 'vendor/autoload.php';
		require 'db.php';
	
	function smail($o,$m)
	{
	
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
	

		// Instantiation and passing `true` enables exceptions
		$mail = new PHPMailer(true);

	
			//Server setting
			// Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   ='prodonate007@gmail.com';                     // SMTP username qmuzwncy@gmail.com
			$mail->Password   = 'Jaimik#64';                             // SMTP password Mail@123
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('from@example.com', 'ProDonate');    // Add a recipient
			$mail->addAddress($m);               // Name is optional
			

			// Attachments
			//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			// Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'PASSWORD RESET OTP';
			$mail->Body    = 'This is your otp <br>'.$o;
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
			
	}
			

	$type=$_POST['idp'];
	$_SESSION['idp']=$type;
	$em=$_POST['em'];
	$_SESSION['email']=$em;
    //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
	if($type=="donor")
	{

		$r=mysqli_query($con,"select * from donar where email='$em'");
		$count=mysqli_num_rows($r);
		if($count)
		{
			$otp=rand(000000,999999);
			$_SESSION['otp']=$otp;
			$_SESSION['time']=time();
			smail($otp,$em);
			header("location:submitotp1.php");
		}
		else
		{
			$_SESSION['noemi']=false;
			header("location:forgotpass.php");
		}

	}
	else if($type=="donee")
	{
		$q="select * from donee where email='$em'";
		$r=mysqli_query($con,$q);
		if(mysqli_num_rows($r))
		{
			$otp=rand(000000,999999);
			$_SESSION['otp']=$otp;
			$_SESSION['time']=time();
			smail($otp,$em);
			header("location:submitotp1.php");
		}
		else
		{
			$_SESSION['noemi']=false;
			header("location:forgotpass.php");
		}
	}
	else
	    echo "Please Try After Sometime";
?>
