<?php
session_start();

    		use PHPMailer\PHPMailer\PHPMailer;
		use PHPMailer\PHPMailer\SMTP;
		use PHPMailer\PHPMailer\Exception;

		// Load Composer's autoloader
		require 'vendor/autoload.php';
	
	function smail($m,$rno,$cn)
	{
	
		// Import PHPMailer classes into the global namespace
		// These must be at the top of your script, not inside a function
	

		// Instantiation and passing `true` enables exceptions
		$mail = new PHPMailer(true);

	
			//Server setting
			// Enable verbose debug output
			$mail->isSMTP();                                            // Send using SMTP
			$mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
			$mail->Username   = 'prodonate007@gmail.com';                     // SMTP username
			$mail->Password   = 'Jaimik#64';             // SMTP password
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
			$mail->Port       = 587;                                    // TCP port to connect to

			//Recipients
			$mail->setFrom('from@example.com', 'ProDonate');    // Add a recipient
			$mail->addAddress($m);               // Name is optional
			

			// Attachments
			//$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

			// Content
			$mail->isHTML(true);                                  // Set email format to HTML
			$mail->Subject = 'PAYMENT CONFIRMATION.';
			$mail->Body    = 'you will recieve payment in next 24 hours for request no '.$rno.'catagory '.$cn;
			$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
		   header("location:paydonee.php");
			
	
	}
$reno=$_SESSION['reno'];
$amt=$_POST['pamt'];
$id=$_SESSION['id'];
$cn=$_SESSION['cn'];
$d=$_SESSION['d'];

$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
$q1="UPDATE wallet SET Balance=Balance-$amt WHERE WID='W0000001'";
$q3="UPDATE application SET pstatus='1' WHERE reno='$reno' AND dnid='$id'";
$q4="select cat_amt from catagory where cat_no='$cn'";

$r=mysqli_query($con,$q4);
$c=mysqli_fetch_array($r);

if(isset($_POST['sub']))
{
if($c['cat_amt']>=$amt)
{
$q="insert into payment (amount,p_date,RNO) values('$amt','$d','$reno')";
if(mysqli_query($con,$q))
{
    $r=mysqli_query($con,$q1);
    $q2="select * from donee where username='$id'";
    $r1=mysqli_query($con,$q2);
    $c1=mysqli_fetch_array($r1);
    $em=$c1['email'];
    $q4="select * from catagory where cat_no='$cn'";
    $q5="UPDATE catagory SET cat_amt=cat_amt-$amt where cat_no='$cn'";
    mysqli_query($con,$q5);
    $r2=mysqli_query($con,$q4);
    $c2=mysqli_fetch_array($r2);
    $cn1=$c2['cat_name'];
    smail($em,$reno,$cn1);
}

}
else
{
    echo "this catagory does not have sufficient amount";
}
}
else
{
    header("location:pay1.php");
}
?>
<html>
    <br/><br/>
    <a href="admin.php">Go Back</a>
</html>