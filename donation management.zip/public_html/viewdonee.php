<?php
//$_SESSION['cat']=$_POST['cat'];
    $id=$_COOKIE['cat'];
    require 'db.php';
    setcookie('ct',$id);
    $timezone = "Asia/Calcutta";
    if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
    $current_d       =  date('Y-m-d');
?>
<html>
    <head>
       <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
       <link rel="stylesheet" type="text/css" href="s2.css">
        <style>
            table{
                margin-left:10%;border-collapse:collapse; width:75%; max-height:100%;
            }
            ::placeholder{
                color:white;
            }
            
        </style>
    </head>
    <body>
      <center>  <form method="post" action="src_donee.php">
            <div class="input-container" style="width:10%;">
                <input type="text" name="amt" placeholder="Enter Amount">
            </div>
            <button class="btn" style="margin:0%;"name="src">Search</button>
        </form>
        </center>
    <table border="2px solid black">
        <tr>
            <th>Application NO</th>
            <th>Donee Name/ ID</th>
            <th>Required Money</th>
            <th>Last Date</th>
            <th>Remarks</th>
        </tr>
        <?php
            // $con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
    
        //$date  = $r1['last_date'];
        //$e  =  date('Y-m-d',strtotime($date));
    $q="select * from application where cat_no=(select cat_no from catagory where cat_name='$id') and last_date>='".$current_d."' ";
    $r=mysqli_query($con,$q);
    
    if(mysqli_num_rows($r)==0)
    {
        echo  "Sorry No Data Available";
    }
    while($c=mysqli_fetch_array($r))
    {    
   ?>
        <tr>
            <td><?php echo $c['reno']; ?></td>
            <td><?php echo $c['dnid']; ?></td>
            <td><?php echo $c['req_m']; ?></td>
            <td><?php echo $c['last_date']; ?></td>
            <td><?php echo $c['remarks']; ?></td>
        </tr>
        
        
    </table>
    </html>
    <?php } ?>