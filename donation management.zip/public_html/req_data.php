<?php
    session_start();
    require 'db.php';
$id=$_SESSION['id'];
    $cn=$_POST['cc'];
    	//$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
	    if(isset($_POST['sub']))
	    {
	        $q1="select * from catagory where cat_name='$cn'";
	        $r1=mysqli_query($con,$q1);
	        $c1=mysqli_fetch_array($r1);
	        $n=$c1['cat_no'];
	        echo $c1['cat_no'];

 $d="select * from donee where username='$id'";
$dc=mysqli_query($con,$d);
	
	 $c2=mysqli_fetch_array($dc);
    	
	    }
 /*if(strcasecmp($c2['State'],$c1['state'])!=0)
    	{

    	    $_SESSION['statec']=false;
$_SESSION['f']=$c1['state'];
$_SESSION['f1']=$c2['State'];
    	    header("location:req.php");
    	    exit();
    	}*/
	

	$rmo=$_POST['money'];
	$bn=$_POST['bk'];
	$acc=$_POST['acc'];
	$ifsc=$_POST['ifsc'];
	$ld=$_POST['LD'];
	$rm=$_POST['rm'];
	if(isset($_FILES['idphoto']) && isset($_FILES['passbook']))
	{
	$idphoto=addslashes(file_get_contents($_FILES['idphoto']['tmp_name']));
	$passbook=addslashes(file_get_contents($_FILES['passbook']['tmp_name']));
		$q2="UPDATE donee SET proof='$idphoto',passbook='$passbook',bname='$bn',acc_no='$acc',ifsc='$ifsc' WHERE username='$id'";
	$q2r=mysqli_query($con,$q2);
	}
	$q="insert into application(req_m,last_date,remarks,cat_no,dnid,aid,status,pstatus) values ('$rmo','$ld','$rm','$n','$id','jash123','0','0')";
	$q1="select * from application where dnid='$id' AND cat_no='$n' AND status='0'";

	$count=mysqli_query($con,$q1);
	if(mysqli_num_rows($count)>0)
	{
		echo " you already requested please wait till acceptance of request by our STAFF";
	
	}
	else
	{
	    $que="select * from application where dnid='$id'";
	    $c=mysqli_query($con,$que);
	    $ans=$rmo;
	    while($r=mysqli_fetch_array($c))
	    {
	        $ans=$ans+$r['req_m'];
	    }
    	if($ans<=8000)
    	{
    	    if(mysqli_query($con,$q))
    	    {
    	        $_SESSION['submitted']=false;
	        	header("location:req.php");
	        	exit();
	    	
    	    }
    	    else
    	    {
    	        echo mysqli_error($con);
    	    }
	    }
    	else
    	{
		    $_SESSION['not']=false;
	       	header("location:req.php");
	       	exit();
    	}
	}
	
?>
	
	