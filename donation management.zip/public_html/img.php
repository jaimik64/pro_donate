<?php
		if(isset($_POST['submit']))
			{
				$filen=$_FILES['file']['name'];
				$filet=$_FILES['file']['type'];
				$files=$_FILES['file']['size'];
				$filetl=$_FILES['file']['tmp_name'];
				$files="images/".$filen;
				move_uploaded_file($filetl,$files);
			}
		
?>
<form action="?" method="POST" enctype="multipart/form-data">
UPLOAD PHOTO:<input type="file" name="file"><br><br>
<input type="submit" name="submit" value="upload"><br><br>
</form>
			