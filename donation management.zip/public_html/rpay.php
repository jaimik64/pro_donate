<html>
    <head>
        <style>
            .rwd-table {
  background: #34495E;
  color: #fff;
  border-radius: .4em;
  overflow: hidden;
  border-color:white;
  border-collapse:collapse;
        </style>
    </head>

<table class="rwd-table" border="2px solid">
		<tr>	
		<th>request no</th>
		<th>amount</th>
		<th>date</th>
		</tr>
		<?php
		    $d=$_GET['req'];
		    require 'db.php';
	        //$con=mysqli_connect("localhost","id11970969_root","root007","id11970969_dms");
			$q="select*from payment where RNO='$d'";
			$c=mysqli_query($con,$q);
			$count=mysqli_num_rows($c);
			if($count>0)
			{
			while($r=mysqli_fetch_array($c))
			{
				$reno=$r['RNO'];				
				$amt=$r['amount'];	
				$date=$r['p_date'];
		?>
		<tr>
			<td><?php echo $reno?></td>
			<td><?php echo $amt?></td>
			<td><?php echo $date?></td>
		</tr>

	
<?php }}
else
{
echo "no payment done to this request..";}?>
</table>
</html>