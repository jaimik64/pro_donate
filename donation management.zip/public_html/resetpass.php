<?php
    session_start();
    if($_SESSION['otp']==true)
    {
        echo "";
    }
    else
    {
        header("location:demo.php");
    }
?>
<html>
    <head>
        <link rel="icon" href="heart.png">
        <title>Reset Password</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" type="text/css" href="s2.css">
    </head>
<body>
    <div class="box">
    <form method="POST" action="resetpass_data.php" autocomplete="on">
        <span class="text-center">Change Password</span>
	<div class="input-container">
		<input type="password" name="pas" minlength="8" required>
		<label>New Password</label>
	</div>
	<div class="input-container">
		<input type="password" name="rpas" minlength="8" required>
		<label>RE-ENTER PASSWORD</label>
	</div>
		<button class="btn"  name="sub">Change Password</button>
</FORM>

<?PHP
		if(isset($_SESSION['wrong']))
		{
			echo "PASSWORD DOES NOT MATCH";
			UNSET($_SESSION['wrong']);
			
		}
		else if(isset($_SESSION['len']))
		{
			echo "PASSWORD MUST BE 8 CHARACTER LONG";
			UNSET($_SESSION['len']);
			
		}
	
?>
</div>
</body>
</html>